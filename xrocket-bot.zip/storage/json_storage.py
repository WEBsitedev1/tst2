import os
import json
import time
import uuid
import logging
import asyncio
import shutil
from typing import Dict, Any, List, Optional, Union, Callable, Type, TypeVar
from datetime import datetime
from pathlib import Path
from filelock import FileLock

logger = logging.getLogger(__name__)

T = TypeVar('T')

class JsonStorage:
    """
    Base class for JSON storage implementations.
    Handles file operations with proper locking to prevent data corruption.
    """
    
    def __init__(self, data_path: str):
        """
        Initialize the JSON storage.
        
        Args:
            data_path: Path to the directory where JSON files will be stored
        """
        self.data_path = Path(data_path)
        self.locks = {}
        
        # Create directory structure if it doesn't exist
        self._create_directory_structure()
    
    def _create_directory_structure(self):
        """Create the necessary directory structure for JSON storage"""
        # Main data directory
        self.data_path.mkdir(exist_ok=True)
        
        # Global data directory
        (self.data_path / "global").mkdir(exist_ok=True)
        
        # Groups directory
        (self.data_path / "groups").mkdir(exist_ok=True)
        
        # Cache directory
        (self.data_path / "cache").mkdir(exist_ok=True)
    
    def _get_lock(self, file_path: Path) -> FileLock:
        """
        Get a file lock for the specified path.
        
        Args:
            file_path: Path to the file to lock
            
        Returns:
            FileLock: A file lock object
        """
        lock_path = str(file_path) + ".lock"
        if lock_path not in self.locks:
            self.locks[lock_path] = FileLock(lock_path)
        return self.locks[lock_path]
    
    async def _read_json_file(self, file_path: Path) -> Dict[str, Any]:
        """
        Read a JSON file with proper locking.
        
        Args:
            file_path: Path to the JSON file
            
        Returns:
            Dict[str, Any]: The JSON data as a dictionary
        """
        lock = self._get_lock(file_path)
        
        try:
            with lock:
                if not file_path.exists():
                    return {}
                
                with open(file_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except json.JSONDecodeError:
            logger.error(f"Error decoding JSON from {file_path}")
            return {}
        except Exception as e:
            logger.error(f"Error reading JSON file {file_path}: {e}")
            return {}
    
    async def _write_json_file(self, file_path: Path, data: Dict[str, Any]) -> bool:
        """
        Write data to a JSON file with proper locking.
        
        Args:
            file_path: Path to the JSON file
            data: Data to write
            
        Returns:
            bool: True if successful, False otherwise
        """
        lock = self._get_lock(file_path)
        
        try:
            # Create parent directories if they don't exist
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Write to a temporary file first
            temp_file = file_path.with_suffix('.tmp')
            
            with lock:
                with open(temp_file, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2, default=self._json_serializer)
                
                # Atomic rename
                shutil.move(str(temp_file), str(file_path))
            
            return True
        except Exception as e:
            logger.error(f"Error writing JSON file {file_path}: {e}")
            return False
    
    def _json_serializer(self, obj):
        """
        Custom JSON serializer for objects not serializable by default json code.
        
        Args:
            obj: Object to serialize
            
        Returns:
            Serialized object
        """
        if isinstance(obj, datetime):
            return obj.isoformat()
        if isinstance(obj, uuid.UUID):
            return str(obj)
        raise TypeError(f"Type {type(obj)} not serializable")


class JsonDbSession(JsonStorage):
    """
    JSON implementation of database session.
    Mimics the SQLAlchemy session interface for database operations.
    """
    
    def __init__(self, data_path: str):
        """
        Initialize the JSON database session.
        
        Args:
            data_path: Path to the directory where JSON files will be stored
        """
        super().__init__(data_path)
        self.pending_operations = []
        self.model_data = {}
    
    async def execute(self, query, params=None):
        """
        Execute a query on the JSON data.
        
        Args:
            query: SQL query or string identifier for the operation
            params: Parameters for the query
            
        Returns:
            JsonQueryResult: Result of the query
        """
        # Parse the query to determine the operation
        if isinstance(query, str):
            # Simple query string, parse it
            if query.lower().startswith("select"):
                return await self._handle_select_query(query, params)
            elif query.lower().startswith("update"):
                return await self._handle_update_query(query, params)
            elif query.lower().startswith("delete"):
                return await self._handle_delete_query(query, params)
            else:
                logger.warning(f"Unsupported query: {query}")
                return JsonQueryResult([])
        else:
            # SQLAlchemy query object, extract information
            # This is a simplified implementation
            model_class = self._extract_model_from_query(query)
            if not model_class:
                logger.warning("Could not extract model from query")
                return JsonQueryResult([])
            
            table_name = model_class.__tablename__
            
            # Load data for this model if not already loaded
            if table_name not in self.model_data:
                await self._load_model_data(model_class)
            
            # Create a result based on the query type
            if hasattr(query, "whereclause"):
                # Filter data based on where clause
                filtered_data = self._filter_data(self.model_data.get(table_name, []), query.whereclause, params)
                return JsonQueryResult(filtered_data)
            else:
                # Return all data for this model
                return JsonQueryResult(self.model_data.get(table_name, []))
    
    def _extract_model_from_query(self, query):
        """
        Extract the model class from a SQLAlchemy query.
        
        Args:
            query: SQLAlchemy query object
            
        Returns:
            Type: Model class or None
        """
        # This is a simplified implementation
        # In a real implementation, we would need to inspect the query object
        if hasattr(query, "entity_description") and hasattr(query.entity_description, "entity"):
            return query.entity_description.entity
        return None
    
    async def _handle_select_query(self, query, params):
        """
        Handle a SELECT query.
        
        Args:
            query: SQL query string
            params: Parameters for the query
            
        Returns:
            JsonQueryResult: Result of the query
        """
        # This is a simplified implementation
        # In a real implementation, we would need to parse the SQL query
        # For now, we'll just extract the table name and return all data
        
        # Extract table name from query
        table_name = self._extract_table_name_from_query(query)
        if not table_name:
            logger.warning(f"Could not extract table name from query: {query}")
            return JsonQueryResult([])
        
        # Load data for this table
        file_path = self.data_path / "global" / f"{table_name}.json"
        data = await self._read_json_file(file_path)
        
        # Convert to list of records
        records = list(data.values())
        
        # Apply filters if params are provided
        if params:
            filtered_records = []
            for record in records:
                match = True
                for key, value in params.items():
                    if key not in record or record[key] != value:
                        match = False
                        break
                if match:
                    filtered_records.append(record)
            records = filtered_records
        
        return JsonQueryResult(records)
    
    async def _handle_update_query(self, query, params):
        """
        Handle an UPDATE query.
        
        Args:
            query: SQL query string
            params: Parameters for the query
            
        Returns:
            JsonQueryResult: Result of the query
        """
        # Extract table name from query
        table_name = self._extract_table_name_from_query(query)
        if not table_name:
            logger.warning(f"Could not extract table name from query: {query}")
            return JsonQueryResult([])
        
        # Add to pending operations
        self.pending_operations.append(("update", table_name, query, params))
        
        return JsonQueryResult([])
    
    async def _handle_delete_query(self, query, params):
        """
        Handle a DELETE query.
        
        Args:
            query: SQL query string
            params: Parameters for the query
            
        Returns:
            JsonQueryResult: Result of the query
        """
        # Extract table name from query
        table_name = self._extract_table_name_from_query(query)
        if not table_name:
            logger.warning(f"Could not extract table name from query: {query}")
            return JsonQueryResult([])
        
        # Add to pending operations
        self.pending_operations.append(("delete", table_name, query, params))
        
        return JsonQueryResult([])
    
    def _extract_table_name_from_query(self, query):
        """
        Extract the table name from a SQL query.
        
        Args:
            query: SQL query string
            
        Returns:
            str: Table name or None
        """
        # This is a simplified implementation
        # In a real implementation, we would need to properly parse the SQL query
        import re
        
        # Try to extract table name from different query types
        if query.lower().startswith("select"):
            match = re.search(r"from\s+(\w+)", query.lower())
            if match:
                return match.group(1)
        elif query.lower().startswith("update"):
            match = re.search(r"update\s+(\w+)", query.lower())
            if match:
                return match.group(1)
        elif query.lower().startswith("delete"):
            match = re.search(r"from\s+(\w+)", query.lower())
            if match:
                return match.group(1)
        
        return None
    
    async def _load_model_data(self, model_class):
        """
        Load data for a model from its JSON file.
        
        Args:
            model_class: Model class
        """
        table_name = model_class.__tablename__
        
        # Determine file path based on model type
        if table_name == "groups":
            # Groups are stored in their own directory
            # We need to load all group files
            groups_dir = self.data_path / "groups"
            self.model_data[table_name] = []
            
            if groups_dir.exists():
                for group_dir in groups_dir.iterdir():
                    if group_dir.is_dir():
                        settings_file = group_dir / "settings.json"
                        if settings_file.exists():
                            group_data = await self._read_json_file(settings_file)
                            if group_data:
                                self.model_data[table_name].append(group_data)
        elif table_name.startswith("game_"):
            # Game-related data is stored in group directories
            # We need to load from all group directories
            self.model_data[table_name] = []
            groups_dir = self.data_path / "groups"
            
            if groups_dir.exists():
                for group_dir in groups_dir.iterdir():
                    if group_dir.is_dir():
                        games_file = group_dir / f"{table_name}.json"
                        if games_file.exists():
                            games_data = await self._read_json_file(games_file)
                            if games_data:
                                self.model_data[table_name].extend(list(games_data.values()))
        else:
            # Other data is stored in global directory
            file_path = self.data_path / "global" / f"{table_name}.json"
            data = await self._read_json_file(file_path)
            self.model_data[table_name] = list(data.values())
    
    def _filter_data(self, data, where_clause, params):
        """
        Filter data based on a where clause.
        
        Args:
            data: List of records
            where_clause: SQLAlchemy where clause
            params: Parameters for the query
            
        Returns:
            List: Filtered records
        """
        # This is a simplified implementation
        # In a real implementation, we would need to properly evaluate the where clause
        if not params:
            return data
        
        filtered_data = []
        for record in data:
            match = True
            for key, value in params.items():
                if key not in record or record[key] != value:
                    match = False
                    break
            if match:
                filtered_data.append(record)
        
        return filtered_data
    
    def add(self, obj):
        """
        Add an object to the session.
        
        Args:
            obj: Object to add
        """
        # Get model class and table name
        model_class = obj.__class__
        table_name = model_class.__tablename__
        
        # Generate ID if needed
        if not getattr(obj, "id", None):
            setattr(obj, "id", str(uuid.uuid4()))
        
        # Add to pending operations
        self.pending_operations.append(("add", table_name, obj, None))
    
    async def commit(self):
        """Commit pending operations"""
        for op_type, table_name, obj_or_query, params in self.pending_operations:
            if op_type == "add":
                await self._commit_add(table_name, obj_or_query)
            elif op_type == "update":
                await self._commit_update(table_name, obj_or_query, params)
            elif op_type == "delete":
                await self._commit_delete(table_name, obj_or_query, params)
        
        # Clear pending operations
        self.pending_operations = []
    
    async def _commit_add(self, table_name, obj):
        """
        Commit an add operation.
        
        Args:
            table_name: Table name
            obj: Object to add
        """
        # Convert object to dictionary
        obj_dict = self._object_to_dict(obj)
        
        # Determine file path based on model type
        if table_name == "groups":
            # Create group directory
            group_id = obj_dict.get("id")
            if not group_id:
                logger.error("Group ID is required")
                return
            
            group_dir = self.data_path / "groups" / str(group_id)
            group_dir.mkdir(parents=True, exist_ok=True)
            
            # Save group settings
            settings_file = group_dir / "settings.json"
            await self._write_json_file(settings_file, obj_dict)
        elif table_name.startswith("game_"):
            # Save game data in group directory
            group_id = obj_dict.get("group_id")
            if not group_id:
                logger.error("Group ID is required for game data")
                return
            
            group_dir = self.data_path / "groups" / str(group_id)
            group_dir.mkdir(parents=True, exist_ok=True)
            
            # Load existing games
            games_file = group_dir / f"{table_name}.json"
            games_data = await self._read_json_file(games_file)
            
            # Add new game
            game_id = obj_dict.get("id")
            if not game_id:
                logger.error("Game ID is required")
                return
            
            games_data[str(game_id)] = obj_dict
            
            # Save games
            await self._write_json_file(games_file, games_data)
        else:
            # Save in global directory
            file_path = self.data_path / "global" / f"{table_name}.json"
            data = await self._read_json_file(file_path)
            
            # Add new object
            obj_id = obj_dict.get("id")
            if not obj_id:
                logger.error("ID is required")
                return
            
            data[str(obj_id)] = obj_dict
            
            # Save data
            await self._write_json_file(file_path, data)
    
    async def _commit_update(self, table_name, query, params):
        """
        Commit an update operation.
        
        Args:
            table_name: Table name
            query: SQL query
            params: Parameters for the query
        """
        # This is a simplified implementation
        # In a real implementation, we would need to properly parse the SQL query
        
        # Load data
        if table_name == "groups":
            # Update group settings
            for group_id, value in params.items():
                if group_id == "group_id":
                    group_dir = self.data_path / "groups" / str(value)
                    if group_dir.exists():
                        settings_file = group_dir / "settings.json"
                        settings_data = await self._read_json_file(settings_file)
                        
                        # Update settings
                        for key, val in params.items():
                            if key != "group_id":
                                settings_data[key] = val
                        
                        # Save settings
                        await self._write_json_file(settings_file, settings_data)
        elif table_name.startswith("game_"):
            # Update game data
            if "game_id" in params and "group_id" in params:
                group_dir = self.data_path / "groups" / str(params["group_id"])
                if group_dir.exists():
                    games_file = group_dir / f"{table_name}.json"
                    games_data = await self._read_json_file(games_file)
                    
                    # Update game
                    game_id = params["game_id"]
                    if str(game_id) in games_data:
                        for key, val in params.items():
                            if key not in ["game_id", "group_id"]:
                                games_data[str(game_id)][key] = val
                        
                        # Save games
                        await self._write_json_file(games_file, games_data)
        else:
            # Update in global directory
            file_path = self.data_path / "global" / f"{table_name}.json"
            data = await self._read_json_file(file_path)
            
            # Update objects that match the parameters
            for obj_id, obj_data in data.items():
                match = True
                for key, value in params.items():
                    if key.endswith("_id") and key != "id":
                        # This is a filter parameter
                        if key not in obj_data or obj_data[key] != value:
                            match = False
                            break
                
                if match:
                    # Update object
                    for key, value in params.items():
                        if not key.endswith("_id") or key == "id":
                            obj_data[key] = value
            
            # Save data
            await self._write_json_file(file_path, data)
    
    async def _commit_delete(self, table_name, query, params):
        """
        Commit a delete operation.
        
        Args:
            table_name: Table name
            query: SQL query
            params: Parameters for the query
        """
        # This is a simplified implementation
        # In a real implementation, we would need to properly parse the SQL query
        
        # Load data
        if table_name == "groups":
            # Delete group
            if "group_id" in params:
                group_dir = self.data_path / "groups" / str(params["group_id"])
                if group_dir.exists():
                    shutil.rmtree(str(group_dir))
        elif table_name.startswith("game_"):
            # Delete game
            if "game_id" in params and "group_id" in params:
                group_dir = self.data_path / "groups" / str(params["group_id"])
                if group_dir.exists():
                    games_file = group_dir / f"{table_name}.json"
                    games_data = await self._read_json_file(games_file)
                    
                    # Delete game
                    game_id = params["game_id"]
                    if str(game_id) in games_data:
                        del games_data[str(game_id)]
                        
                        # Save games
                        await self._write_json_file(games_file, games_data)
        else:
            # Delete from global directory
            file_path = self.data_path / "global" / f"{table_name}.json"
            data = await self._read_json_file(file_path)
            
            # Delete objects that match the parameters
            to_delete = []
            for obj_id, obj_data in data.items():
                match = True
                for key, value in params.items():
                    if key not in obj_data or obj_data[key] != value:
                        match = False
                        break
                
                if match:
                    to_delete.append(obj_id)
            
            # Delete objects
            for obj_id in to_delete:
                del data[obj_id]
            
            # Save data
            await self._write_json_file(file_path, data)
    
    async def rollback(self):
        """Rollback pending operations"""
        self.pending_operations = []
    
    async def close(self):
        """Close the session"""
        self.pending_operations = []
        self.model_data = {}
    
    async def refresh(self, obj):
        """
        Refresh an object from the database.
        
        Args:
            obj: Object to refresh
        """
        # Get model class and table name
        model_class = obj.__class__
        table_name = model_class.__tablename__
        
        # Get object ID
        obj_id = getattr(obj, "id", None)
        if not obj_id:
            logger.error("Object ID is required for refresh")
            return
        
        # Load data
        if table_name == "groups":
            # Load group settings
            group_dir = self.data_path / "groups" / str(obj_id)
            if group_dir.exists():
                settings_file = group_dir / "settings.json"
                settings_data = await self._read_json_file(settings_file)
                
                # Update object
                for key, value in settings_data.items():
                    setattr(obj, key, value)
        elif table_name.startswith("game_"):
            # Load game data
            group_id = getattr(obj, "group_id", None)
            if not group_id:
                logger.error("Group ID is required for game data")
                return
            
            group_dir = self.data_path / "groups" / str(group_id)
            if group_dir.exists():
                games_file = group_dir / f"{table_name}.json"
                games_data = await self._read_json_file(games_file)
                
                # Update object
                if str(obj_id) in games_data:
                    for key, value in games_data[str(obj_id)].items():
                        setattr(obj, key, value)
        else:
            # Load from global directory
            file_path = self.data_path / "global" / f"{table_name}.json"
            data = await self._read_json_file(file_path)
            
            # Update object
            if str(obj_id) in data:
                for key, value in data[str(obj_id)].items():
                    setattr(obj, key, value)
    
    def _object_to_dict(self, obj):
        """
        Convert an object to a dictionary.
        
        Args:
            obj: Object to convert
            
        Returns:
            Dict[str, Any]: Dictionary representation of the object
        """
        obj_dict = {}
        for column in obj.__table__.columns:
            value = getattr(obj, column.name)
            obj_dict[column.name] = value
        return obj_dict


class JsonQueryResult:
    """
    Result of a JSON query.
    Mimics the SQLAlchemy query result interface.
    """
    
    def __init__(self, data):
        """
        Initialize the query result.
        
        Args:
            data: Query result data
        """
        self.data = data
    
    def scalar_one_or_none(self):
        """
        Get the first result or None.
        
        Returns:
            Any: First result or None
        """
        if not self.data:
            return None
        return self.data[0]
    
    def scalars(self):
        """
        Get all results.
        
        Returns:
            JsonScalars: Scalars object
        """
        return JsonScalars(self.data)
    
    def fetchone(self):
        """
        Fetch one result.
        
        Returns:
            Any: First result or None
        """
        if not self.data:
            return None
        return self.data[0]
    
    def fetchall(self):
        """
        Fetch all results.
        
        Returns:
            List: All results
        """
        return self.data


class JsonScalars:
    """
    Scalars from a JSON query result.
    Mimics the SQLAlchemy scalars interface.
    """
    
    def __init__(self, data):
        """
        Initialize the scalars.
        
        Args:
            data: Scalars data
        """
        self.data = data
    
    def all(self):
        """
        Get all scalars.
        
        Returns:
            List: All scalars
        """
        return self.data


class JsonRedisCache(JsonStorage):
    """
    JSON implementation of Redis cache.
    Mimics the Redis cache interface for temporary data.
    """
    
    def __init__(self, data_path: str):
        """
        Initialize the JSON Redis cache.
        
        Args:
            data_path: Path to the directory where JSON files will be stored
        """
        super().__init__(data_path)
        self.cache_dir = self.data_path / "cache"
        self.cache_dir.mkdir(exist_ok=True)
    
    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """
        Set a key with value and optional TTL in seconds.
        
        Args:
            key: Key to set
            value: Value to set
            ttl: Time to live in seconds
            
        Returns:
            bool: True if successful, False otherwise
        """
        # Sanitize key for filename
        safe_key = self._sanitize_key(key)
        file_path = self.cache_dir / f"{safe_key}.json"
        
        # Prepare data with TTL
        data = {
            "value": value,
            "expires_at": time.time() + ttl if ttl else None
        }
        
        # Write to file
        return await self._write_json_file(file_path, data)
    
    async def get(self, key: str) -> Optional[Any]:
        """
        Get a value by key.
        
        Args:
            key: Key to get
            
        Returns:
            Any: Value or None
        """
        # Sanitize key for filename
        safe_key = self._sanitize_key(key)
        file_path = self.cache_dir / f"{safe_key}.json"
        
        # Read data
        data = await self._read_json_file(file_path)
        if not data:
            return None
        
        # Check expiration
        expires_at = data.get("expires_at")
        if expires_at and time.time() > expires_at:
            # Expired, delete file
            await self.delete(key)
            return None
        
        return data.get("value")
    
    async def delete(self, key: str) -> bool:
        """
        Delete a key.
        
        Args:
            key: Key to delete
            
        Returns:
            bool: True if successful, False otherwise
        """
        # Sanitize key for filename
        safe_key = self._sanitize_key(key)
        file_path = self.cache_dir / f"{safe_key}.json"
        
        # Delete file if it exists
        if file_path.exists():
            try:
                file_path.unlink()
                return True
            except Exception as e:
                logger.error(f"Error deleting cache file {file_path}: {e}")
                return False
        
        return True
    
    async def exists(self, key: str) -> bool:
        """
        Check if a key exists.
        
        Args:
            key: Key to check
            
        Returns:
            bool: True if key exists, False otherwise
        """
        # Sanitize key for filename
        safe_key = self._sanitize_key(key)
        file_path = self.cache_dir / f"{safe_key}.json"
        
        # Check if file exists and not expired
        if file_path.exists():
            data = await self._read_json_file(file_path)
            if not data:
                return False
            
            # Check expiration
            expires_at = data.get("expires_at")
            if expires_at and time.time() > expires_at:
                # Expired, delete file
                await self.delete(key)
                return False
            
            return True
        
        return False
    
    async def close(self):
        """Close the cache"""
        # Nothing to do for JSON cache
        pass
    
    def _sanitize_key(self, key: str) -> str:
        """
        Sanitize a key for use as a filename.
        
        Args:
            key: Key to sanitize
            
        Returns:
            str: Sanitized key
        """
        # Replace invalid characters with underscore
        import re
        return re.sub(r'[^\w\-\.]', '_', key)


class JsonSessionMaker:
    """
    Factory for creating JSON database sessions.
    Mimics the SQLAlchemy session maker interface.
    """
    
    def __init__(self, data_path: str):
        """
        Initialize the session maker.
        
        Args:
            data_path: Path to the directory where JSON files will be stored
        """
        self.data_path = data_path
    
    def __call__(self):
        """
        Create a new session.
        
        Returns:
            JsonDbSession: New session
        """
        return JsonDbSession(self.data_path)

