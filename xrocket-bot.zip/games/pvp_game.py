import asyncio
import logging
import uuid
from typing import Dict, Any, List, Tuple, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from datetime import datetime, timedelta

from database.models import Game, GameParticipant, User, PvpSession, Transaction
from config.config import load_config

logger = logging.getLogger(__name__)

class PvpGame:
    """
    Manages the PvP game logic
    """
    
    def __init__(self, session: AsyncSession, payment_service):
        self.session = session
        self.payment_service = payment_service
        self.config = load_config()
    
    async def create_challenge(
        self, 
        challenger_id: int, 
        opponent_username: str, 
        stake: float, 
        currency: str,
        group_id: int
    ) -> Tuple[bool, str, Optional[str]]:
        """
        Create a PvP challenge
        
        Args:
            challenger_id: Challenger user ID
            opponent_username: Opponent username
            stake: Stake amount
            currency: Currency code
            group_id: Telegram group ID
            
        Returns:
            Tuple[bool, str, Optional[str]]: (success, message, game_id)
        """
        try:
            # Check if webhooks are enabled
            if not self.config.xrocket.use_webhooks:
                return False, "Webhooks are disabled. PvP games require webhooks to process payments.", None
            
            # Get challenger
            result = await self.session.execute(
                select(User).where(User.id == challenger_id)
            )
            challenger = result.scalar_one_or_none()
            
            if not challenger:
                return False, "Challenger not found", None
            
            # Get opponent by username
            opponent_username = opponent_username.lstrip('@')
            result = await self.session.execute(
                select(User).where(User.username == opponent_username)
            )
            opponent = result.scalar_one_or_none()
            
            if not opponent:
                return False, f"User @{opponent_username} not found", None
            
            # Check if there's an active PvP game for either user
            result = await self.session.execute(
                select(PvpSession).join(Game).where(
                    (PvpSession.challenger_id == challenger_id) | 
                    (PvpSession.opponent_id == challenger_id) |
                    (PvpSession.challenger_id == opponent.id) | 
                    (PvpSession.opponent_id == opponent.id),
                    Game.status == "active"
                )
            )
            active_session = result.scalar_one_or_none()
            
            if active_session:
                return False, "One of the players already has an active PvP game", None
            
            # Get minimum stake
            min_stake_setting = await self.session.execute(
                select(GlobalSetting).where(GlobalSetting.setting_key == "pvp_min_stake")
            )
            min_stake_setting = min_stake_setting.scalar_one_or_none()
            min_stake = float(min_stake_setting.setting_value) if min_stake_setting else 0.1
            
            if stake < min_stake:
                return False, f"Minimum stake is {min_stake} {currency}", None
            
            # Create game
            game = Game(
                group_id=group_id,
                game_type="pvp",
                prize_amount=stake,
                prize_currency=currency,
                attempts_limit=3,
                status="pending"
            )
            
            self.session.add(game)
            await self.session.commit()
            await self.session.refresh(game)
            
            # Create PvP session
            pvp_session = PvpSession(
                challenger_id=challenger_id,
                opponent_id=opponent.id,
                game_id=game.id,
                result="pending"
            )
            
            self.session.add(pvp_session)
            await self.session.commit()
            
            # Create transaction for challenger's stake
            transaction_id = str(uuid.uuid4())
            transaction = Transaction(
                id=transaction_id,
                user_id=challenger_id,
                group_id=group_id,
                amount=stake / 2,  # Half of the total stake
                currency=currency,
                type="game_entry",
                status="pending"
            )
            
            self.session.add(transaction)
            await self.session.commit()
            
            # Create invoice for challenger
            success, message, _ = await self.payment_service.send_prize(
                user_id=challenger_id,
                amount=-(stake / 2),  # Negative amount for payment
                currency=currency,
                group_id=group_id,
                transaction_type="game_entry"
            )
            
            if not success:
                # Cancel game and session
                game.status = "cancelled"
                await self.session.commit()
                return False, f"Failed to create payment: {message}", None
            
            return True, f"Challenge created. Waiting for payment confirmation.", str(game.id)
            
        except Exception as e:
            await self.session.rollback()
            logger.error(f"Error creating PvP challenge: {e}")
            return False, f"Error: {str(e)}", None
    
    async def accept_challenge(
        self, 
        game_id: str, 
        opponent_id: int
    ) -> Tuple[bool, str]:
        """
        Accept a PvP challenge
        
        Args:
            game_id: Game UUID
            opponent_id: Opponent user ID
            
        Returns:
            Tuple[bool, str]: (success, message)
        """
        try:
            # Get game
            result = await self.session.execute(
                select(Game).where(Game.id == game_id)
            )
            game = result.scalar_one_or_none()
            
            if not game:
                return False, "Game not found"
            
            if game.status != "pending":
                return False, "Game is not in pending state"
            
            # Get PvP session
            result = await self.session.execute(
                select(PvpSession).where(PvpSession.game_id == game_id)
            )
            pvp_session = result.scalar_one_or_none()
            
            if not pvp_session:
                return False, "PvP session not found"
            
            if pvp_session.opponent_id != opponent_id:
                return False, "You are not the opponent for this challenge"
            
            # Create transaction for opponent's stake
            transaction_id = str(uuid.uuid4())
            transaction = Transaction(
                id=transaction_id,
                user_id=opponent_id,
                group_id=game.group_id,
                amount=game.prize_amount / 2,  # Half of the total stake
                currency=game.prize_currency,
                type="game_entry",
                status="pending"
            )
            
            self.session.add(transaction)
            await self.session.commit()
            
            # Create invoice for opponent
            success, message, _ = await self.payment_service.send_prize(
                user_id=opponent_id,
                amount=-(game.prize_amount / 2),  # Negative amount for payment
                currency=game.prize_currency,
                group_id=game.group_id,
                transaction_type="game_entry"
            )
            
            if not success:
                # Cancel game and session
                game.status = "cancelled"
                await self.session.commit()
                return False, f"Failed to create payment: {message}"
            
            return True, f"Challenge accepted. Waiting for payment confirmation."
            
        except Exception as e:
            await self.session.rollback()
            logger.error(f"Error accepting PvP challenge: {e}")
            return False, f"Error: {str(e)}"
    
    async def process_dice(
        self, 
        game_id: str, 
        user_id: int, 
        value: int
    ) -> Tuple[bool, str, Dict[str, Any]]:
        """
        Process a dice roll in PvP game
        
        Args:
            game_id: Game UUID
            user_id: User ID
            value: Dice value (1-6)
            
        Returns:
            Tuple[bool, str, Dict[str, Any]]: (success, message, game_state)
        """
        try:
            # Get game
            result = await self.session.execute(
                select(Game).where(Game.id == game_id)
            )
            game = result.scalar_one_or_none()
            
            if not game:
                return False, "Game not found", {}
            
            if game.status != "active":
                return False, "Game is not active", {}
            
            # Get PvP session
            result = await self.session.execute(
                select(PvpSession).where(PvpSession.game_id == game_id)
            )
            pvp_session = result.scalar_one_or_none()
            
            if not pvp_session:
                return False, "PvP session not found", {}
            
            # Check if user is part of the game
            if user_id != pvp_session.challenger_id and user_id != pvp_session.opponent_id:
                return False, "You are not part of this game", {}
            
            # Update attempts and score
            is_challenger = (user_id == pvp_session.challenger_id)
            
            if is_challenger:
                if pvp_session.challenger_attempts >= game.attempts_limit:
                    return False, "You have used all your attempts", {}
                
                pvp_session.challenger_attempts += 1
                pvp_session.challenger_score += value
            else:
                if pvp_session.opponent_attempts >= game.attempts_limit:
                    return False, "You have used all your attempts", {}
                
                pvp_session.opponent_attempts += 1
                pvp_session.opponent_score += value
            
            await self.session.commit()
            
            # Check if game is complete
            game_complete = (
                pvp_session.challenger_attempts >= game.attempts_limit and 
                pvp_session.opponent_attempts >= game.attempts_limit
            )
            
            if game_complete:
                # Determine winner
                if pvp_session.challenger_score > pvp_session.opponent_score:
                    pvp_session.result = "challenger_win"
                    winner_id = pvp_session.challenger_id
                elif pvp_session.opponent_score > pvp_session.challenger_score:
                    pvp_session.result = "opponent_win"
                    winner_id = pvp_session.opponent_id
                else:
                    pvp_session.result = "draw"
                    winner_id = None
                
                game.status = "completed"
                await self.session.commit()
                
                # Send prize to winner
                if winner_id:
                    success, message, _ = await self.payment_service.send_prize(
                        user_id=winner_id,
                        amount=game.prize_amount,
                        currency=game.prize_currency,
                        group_id=game.group_id,
                        transaction_type="prize"
                    )
                    
                    if not success:
                        logger.error(f"Failed to send prize: {message}")
                
                # Get user info
                result = await self.session.execute(
                    select(User).where(User.id == pvp_session.challenger_id)
                )
                challenger = result.scalar_one_or_none()
                
                result = await self.session.execute(
                    select(User).where(User.id == pvp_session.opponent_id)
                )
                opponent = result.scalar_one_or_none()
                
                # Return game state
                return True, "Game completed", {
                    "complete": True,
                    "challenger": {
                        "id": pvp_session.challenger_id,
                        "username": challenger.username if challenger else None,
                        "attempts": pvp_session.challenger_attempts,
                        "score": pvp_session.challenger_score
                    },
                    "opponent": {
                        "id": pvp_session.opponent_id,
                        "username": opponent.username if opponent else None,
                        "attempts": pvp_session.opponent_attempts,
                        "score": pvp_session.opponent_score
                    },
                    "result": pvp_session.result,
                    "winner_id": winner_id
                }
            
            # Return current game state
            return True, "Dice processed", {
                "complete": False,
                "challenger_attempts": pvp_session.challenger_attempts,
                "challenger_score": pvp_session.challenger_score,
                "opponent_attempts": pvp_session.opponent_attempts,
                "opponent_score": pvp_session.opponent_score
            }
            
        except Exception as e:
            await self.session.rollback()
            logger.error(f"Error processing dice in PvP game: {e}")
            return False, f"Error: {str(e)}", {}
    
    async def start_game(self, game_id: str) -> Tuple[bool, str]:
        """
        Start a PvP game after both players have paid
        
        Args:
            game_id: Game UUID
            
        Returns:
            Tuple[bool, str]: (success, message)
        """
        try:
            # Get game
            result = await self.session.execute(
                select(Game).where(Game.id == game_id)
            )
            game = result.scalar_one_or_none()
            
            if not game:
                return False, "Game not found"
            
            if game.status != "pending":
                return False, "Game is not in pending state"
            
            # Update game status
            game.status = "active"
            await self.session.commit()
            
            return True, "Game started"
            
        except Exception as e:
            await self.session.rollback()
            logger.error(f"Error starting PvP game: {e}")
            return False, f"Error: {str(e)}"
    
    async def cancel_game(self, game_id: str) -> Tuple[bool, str]:
        """
        Cancel a PvP game
        
        Args:
            game_id: Game UUID
            
        Returns:
            Tuple[bool, str]: (success, message)
        """
        try:
            # Get game
            result = await self.session.execute(
                select(Game).where(Game.id == game_id)
            )
            game = result.scalar_one_or_none()
            
            if not game:
                return False, "Game not found"
            
            if game.status == "completed":
                return False, "Game is already completed"
            
            # Get PvP session
            result = await self.session.execute(
                select(PvpSession).where(PvpSession.game_id == game_id)
            )
            pvp_session = result.scalar_one_or_none()
            
            if not pvp_session:
                return False, "PvP session not found"
            
            # Update game status
            game.status = "cancelled"
            await self.session.commit()
            
            # Refund players if they have paid
            # Get transactions
            result = await self.session.execute(
                select(Transaction).where(
                    Transaction.user_id.in_([pvp_session.challenger_id, pvp_session.opponent_id]),
                    Transaction.type == "game_entry",
                    Transaction.status == "completed"
                )
            )
            transactions = result.scalars().all()
            
            for transaction in transactions:
                # Refund the player
                await self.payment_service.send_prize(
                    user_id=transaction.user_id,
                    amount=transaction.amount,  # Original amount
                    currency=game.prize_currency,
                    group_id=game.group_id,
                    transaction_type="refund"
                )
            
            return True, "Game cancelled"
            
        except Exception as e:
            await self.session.rollback()
            logger.error(f"Error cancelling PvP game: {e}")
            return False, f"Error: {str(e)}"
    
    async def check_payment_timeouts(self) -> None:
        """
        Check for PvP games with payment timeouts
        This should be run periodically
        """
        try:
            # Get payment timeout setting
            result = await self.session.execute(
                select(GlobalSetting).where(GlobalSetting.setting_key == "pvp_payment_timeout")
            )
            timeout_setting = result.scalar_one_or_none()
            timeout_minutes = int(timeout_setting.setting_value) if timeout_setting else 5
            
            # Calculate cutoff time
            cutoff_time = datetime.utcnow() - timedelta(minutes=timeout_minutes)
            
            # Get pending games older than cutoff time
            result = await self.session.execute(
                select(Game).where(
                    Game.game_type == "pvp",
                    Game.status == "pending",
                    Game.start_time < cutoff_time
                )
            )
            pending_games = result.scalars().all()
            
            for game in pending_games:
                # Cancel the game
                await self.cancel_game(str(game.id))
                logger.info(f"Cancelled PvP game {game.id} due to payment timeout")
            
        except Exception as e:
            logger.error(f"Error checking PvP payment timeouts: {e}")

