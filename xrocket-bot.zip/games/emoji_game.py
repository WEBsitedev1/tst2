import asyncio
import logging
from typing import Dict, Any, List, Tuple, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from datetime import datetime

from database.models import Game, GameParticipant, User, Group
from config.config import load_config

logger = logging.getLogger(__name__)

class EmojiGame:
    """
    Manages the Emoji game logic
    """
    
    # Winning values for different emoji types
    EMOJI_VALUES = {
        '🎰': {'win': [64], 'semi': [1, 22, 43]},
        '🎲': {'win': [6], 'semi': [3, 4, 5]},
        '🏀': {'win': [5], 'semi': [4]},
        '⚽': {'win': [5], 'semi': [4]},
        '🎳': {'win': [6], 'semi': [4, 5]},
        '🎯': {'win': [6], 'semi': [5]}
    }
    
    def __init__(self, session: AsyncSession, payment_service):
        self.session = session
        self.payment_service = payment_service
        self.config = load_config()
    
    async def start_game(self, group_id: int, emoji_type: str, settings: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Start a new emoji game
        
        Args:
            group_id: Telegram group ID
            emoji_type: Type of emoji for the game
            settings: Game settings
            
        Returns:
            Tuple[bool, str]: (success, message)
        """
        try:
            # Check if a game is already running
            result = await self.session.execute(
                select(Game).where(
                    Game.group_id == group_id,
                    Game.status == "active"
                )
            )
            existing_game = result.scalar_one_or_none()
            
            if existing_game:
                return False, "A game is already running in this group"
            
            # Check if webhooks are required but disabled
            if not self.config.xrocket.use_webhooks and settings.get("prize_amount", 0) > 0:
                return False, "Webhooks are disabled. Games with prizes require webhooks. Please check your webhook settings."
            
            # Create new game
            game = Game(
                group_id=group_id,
                game_type="emoji",
                emoji_type=emoji_type,
                infinite_mode=settings.get("infinite_game", False),
                semi_wins_enabled=settings.get("semi_win", False),
                prize_amount=settings.get("prize_amount", 0.0),
                prize_currency=settings.get("coin_selection", "TON"),
                attempts_limit=settings.get("attempts_limit", 3),
                custom_prize_type=settings.get("custom_prize_type"),
                custom_prize_value=settings.get("custom_prize_value"),
                status="active",
                start_time=datetime.utcnow()
            )
            
            self.session.add(game)
            await self.session.commit()
            await self.session.refresh(game)
            
            return True, f"Emoji game started with {emoji_type}"
            
        except Exception as e:
            await self.session.rollback()
            logger.error(f"Error starting emoji game: {e}")
            return False, f"Error: {str(e)}"
    
    async def stop_game(self, group_id: int) -> Tuple[bool, str]:
        """
        Stop an active emoji game
        
        Args:
            group_id: Telegram group ID
            
        Returns:
            Tuple[bool, str]: (success, message)
        """
        try:
            # Find active game
            result = await self.session.execute(
                select(Game).where(
                    Game.group_id == group_id,
                    Game.status == "active",
                    Game.game_type == "emoji"
                )
            )
            game = result.scalar_one_or_none()
            
            if not game:
                return False, "No active emoji game found"
            
            # Update game status
            game.status = "completed"
            game.end_time = datetime.utcnow()
            await self.session.commit()
            
            return True, "Emoji game stopped"
            
        except Exception as e:
            await self.session.rollback()
            logger.error(f"Error stopping emoji game: {e}")
            return False, f"Error: {str(e)}"
    
    async def add_participant(self, game_id: str, user_id: int) -> Tuple[bool, str]:
        """
        Add a participant to the game
        
        Args:
            game_id: Game UUID
            user_id: User ID
            
        Returns:
            Tuple[bool, str]: (success, message)
        """
        try:
            # Check if user is already a participant
            result = await self.session.execute(
                select(GameParticipant).where(
                    GameParticipant.game_id == game_id,
                    GameParticipant.user_id == user_id
                )
            )
            participant = result.scalar_one_or_none()
            
            if participant:
                return True, "User is already a participant"
            
            # Add new participant
            participant = GameParticipant(
                game_id=game_id,
                user_id=user_id,
                attempts_used=0,
                score=0
            )
            
            self.session.add(participant)
            await self.session.commit()
            
            return True, "User added as participant"
            
        except Exception as e:
            await self.session.rollback()
            logger.error(f"Error adding participant: {e}")
            return False, f"Error: {str(e)}"
    
    async def process_emoji(
        self, 
        group_id: int, 
        user_id: int, 
        emoji: str, 
        value: int
    ) -> Tuple[bool, str, bool, Dict[str, Any]]:
        """
        Process an emoji sent by a user
        
        Args:
            group_id: Telegram group ID
            user_id: User ID
            emoji: The emoji sent
            value: The value of the emoji
            
        Returns:
            Tuple[bool, str, bool, Dict[str, Any]]: (success, message, is_winner, game_info)
        """
        try:
            # Find active game
            result = await self.session.execute(
                select(Game).where(
                    Game.group_id == group_id,
                    Game.status == "active",
                    Game.game_type == "emoji"
                )
            )
            game = result.scalar_one_or_none()
            
            if not game:
                return False, "No active emoji game", False, {}
            
            # Check if emoji matches game emoji
            if emoji != game.emoji_type:
                return False, "Wrong emoji type", False, {}
            
            # Find participant
            result = await self.session.execute(
                select(GameParticipant).where(
                    GameParticipant.game_id == game.id,
                    GameParticipant.user_id == user_id
                )
            )
            participant = result.scalar_one_or_none()
            
            if not participant:
                return False, "User is not a participant", False, {}
            
            # Check attempts limit
            if not game.infinite_mode and participant.attempts_used >= game.attempts_limit:
                return False, f"Attempts limit ({game.attempts_limit}) exceeded", False, {}
            
            # Update attempts
            participant.attempts_used += 1
            participant.score = max(participant.score, value)
            await self.session.commit()
            
            # Check if it's a winning value
            win_values = self.EMOJI_VALUES.get(emoji, {'win': [], 'semi': []})['win']
            semi_win_values = self.EMOJI_VALUES.get(emoji, {'win': [], 'semi': []})['semi']
            
            is_winner = value in win_values
            is_semi_winner = value in semi_win_values and game.semi_wins_enabled
            
            game_info = {
                'game_id': str(game.id),
                'emoji_type': game.emoji_type,
                'value': value,
                'attempts_used': participant.attempts_used,
                'attempts_limit': game.attempts_limit,
                'infinite_mode': game.infinite_mode,
                'is_winner': is_winner,
                'is_semi_winner': is_semi_winner,
                'prize_amount': game.prize_amount,
                'prize_currency': game.prize_currency
            }
            
            if is_winner or is_semi_winner:
                prize_amount = game.prize_amount
                
                if prize_amount > 0:
                    # Check if webhooks are enabled for prize payments
                    if not self.config.xrocket.use_webhooks:
                        return True, "You won, but prizes cannot be sent because webhooks are disabled.", True, game_info
                    
                    # Send prize
                    success, message, _ = await self.payment_service.send_prize(
                        user_id=user_id,
                        amount=prize_amount,
                        currency=game.prize_currency,
                        group_id=group_id,
                        transaction_type="prize"
                    )
                    
                    if not game.infinite_mode:
                        # End game if not infinite
                        game.status = "completed"
                        game.end_time = datetime.utcnow()
                        await self.session.commit()
                    
                    return True, message, True, game_info
            
            return True, "Emoji processed", is_winner or is_semi_winner, game_info
            
        except Exception as e:
            await self.session.rollback()
            logger.error(f"Error processing emoji: {e}")
            return False, f"Error: {str(e)}", False, {}
    
    async def reset_attempts(self, game_id: str) -> Tuple[bool, str]:
        """
        Reset attempts for all participants
        
        Args:
            game_id: Game UUID
            
        Returns:
            Tuple[bool, str]: (success, message)
        """
        try:
            # Update all participants
            result = await self.session.execute(
                select(GameParticipant).where(GameParticipant.game_id == game_id)
            )
            participants = result.scalars().all()
            
            for participant in participants:
                participant.attempts_used = 0
            
            await self.session.commit()
            
            return True, "Attempts reset for all participants"
            
        except Exception as e:
            await self.session.rollback()
            logger.error(f"Error resetting attempts: {e}")
            return False, f"Error: {str(e)}"
    
    def check_winning_value(self, emoji: str, value: int, semi_wins_enabled: bool = False) -> Tuple[bool, bool]:
        """
        Check if a value is a winning value for the given emoji
        
        Args:
            emoji: Emoji type
            value: Value to check
            semi_wins_enabled: Whether semi-wins are enabled
            
        Returns:
            Tuple[bool, bool]: (is_winner, is_semi_winner)
        """
        if emoji not in self.EMOJI_VALUES:
            return False, False
        
        is_winner = value in self.EMOJI_VALUES[emoji]['win']
        is_semi_winner = semi_wins_enabled and value in self.EMOJI_VALUES[emoji]['semi']
        
        return is_winner, is_semi_winner

