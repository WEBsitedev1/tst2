import asyncio
import logging
import math
import random
import tempfile
from io import BytesIO
from typing import Dict, Tuple, Optional, List
import cairo
from PIL import Image, ImageDraw, ImageFont
from datetime import datetime
from sqlalchemy import select
import os
import shutil

logger = logging.getLogger(__name__)

class FortuneWheel:
    """
    Generates a spinning wheel of fortune animation as a GIF.
    Each sector represents a user with a size proportional to their tickets.
    """
    
    def __init__(self, sectors: Dict[str, int], size: int = 800):
        """
        Initialize the wheel with sectors
        
        Args:
            sectors: Dictionary mapping user IDs to number of tickets
            size: Size of the wheel image in pixels
        """
        self.sectors = sectors
        self.sector_count = len(sectors)
        self.total_cells = sum(sectors.values())
        self.start_angle = random.uniform(0, 2 * math.pi)
        self.size = size
        self.outer_radius = (self.size / 2) - 60
        self.inner_radius = self.outer_radius - 180
        self.sector_colors = self._generate_sector_colors()
        self.sector_angles = self._calculate_angles()
    
    def _hsv_to_rgb(self, h: float, s: float, v: float) -> Tuple[float, float, float]:
        """Convert HSV color to RGB"""
        h = float(h) % 360
        s = float(s)
        v = float(v)
        h60 = h / 60.0
        h60f = math.floor(h60)
        hi = int(h60f) % 6
        f = h60 - h60f
        p = v * (1 - s)
        q = v * (1 - f * s)
        t = v * (1 - (1 - f) * s)
        
        if hi == 0: return v, t, p
        elif hi == 1: return q, v, p
        elif hi == 2: return p, v, t
        elif hi == 3: return p, q, v
        elif hi == 4: return t, p, v
        elif hi == 5: return v, p, q
        
        return 0, 0, 0
    
    def _generate_sector_colors(self) -> Dict[str, Tuple[float, float, float]]:
        """Generate colors for each sector"""
        colors = {}
        hue_step = 360 / len(self.sectors)
        
        for i, name in enumerate(self.sectors):
            hue = (i * hue_step) % 360
            colors[name] = self._hsv_to_rgb(hue, 0.8, 0.9)
        
        return colors
    
    def _calculate_angles(self) -> Dict[str, Tuple[float, float]]:
        """Calculate start and end angles for each sector"""
        angles = {}
        current_angle = 0
        angle_multiplier = 2 * math.pi / self.total_cells
        
        for name, weight in self.sectors.items():
            sector_angle = weight * angle_multiplier
            angles[name] = (current_angle, current_angle + sector_angle)
            current_angle += sector_angle
        
        return angles
    
    def _draw_sector(self, ctx: cairo.Context, name: str, start_angle: float, end_angle: float):
        """Draw a sector of the wheel"""
        ctx.save()
        ctx.move_to(0, 0)
        ctx.arc(0, 0, self.outer_radius, start_angle, end_angle)
        ctx.close_path()
        ctx.set_source_rgb(*self.sector_colors[name])
        ctx.fill_preserve()
        ctx.set_source_rgb(1, 1, 1)
        ctx.set_line_width(2)
        ctx.stroke()
        
        # Draw text in the middle of the sector
        text_angle = (start_angle + end_angle) / 2
        ctx.rotate(text_angle)
        ctx.set_font_size(28)
        ctx.select_font_face("", cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.move_to(self.inner_radius + 1, 15)
        ctx.set_source_rgb(1, 1, 1)
        ctx.show_text(name)
        ctx.restore()
    
    def draw_frame(self, rotation_angle: float) -> Image.Image:
        """Draw a single frame of the wheel animation"""
        surface = cairo.ImageSurface(cairo.FORMAT_ARGB32, self.size, self.size)
        ctx = cairo.Context(surface)
        
        # Set up the context
        ctx.translate(self.size / 2, self.size / 2)
        ctx.rotate(rotation_angle + self.start_angle)
        
        # Draw wheel background
        ctx.arc(0, 0, self.outer_radius + 15, 0, 2 * math.pi)
        ctx.set_source_rgb(0.8, 0.7, 0.2)
        ctx.fill()
        
        # Draw sectors
        for name, (start_angle, end_angle) in self.sector_angles.items():
            self._draw_sector(ctx, name, start_angle, end_angle)
        
        # Draw center and pointer
        ctx.rotate(-(rotation_angle + self.start_angle))
        
        # Draw center circle
        ctx.arc(0, 0, self.inner_radius - 15, 0, 2 * math.pi)
        ctx.set_source_rgb(0.2, 0.2, 0.2)
        ctx.fill()
        
        # Draw pointer
        pointer_size = 60
        ctx.move_to(self.outer_radius - 5, 0)
        ctx.line_to(self.outer_radius + pointer_size, pointer_size / 2)
        ctx.line_to(self.outer_radius + pointer_size, -pointer_size / 2)
        ctx.close_path()
        ctx.set_source_rgb(0.9, 0.2, 0.2)
        ctx.fill_preserve()
        ctx.set_source_rgb(1, 1, 1)
        ctx.set_line_width(2)
        ctx.stroke()
        
        # Add timestamp to prevent caching issues
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
        ctx.set_font_size(12)
        ctx.select_font_face("", cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
        ctx.move_to(-self.outer_radius + 10, -self.outer_radius + 20)
        ctx.set_source_rgba(1, 1, 1, 0.5)  # Semi-transparent white
        ctx.show_text(timestamp)
        
        # Convert to PIL Image
        buf = BytesIO()
        surface.write_to_png(buf)
        buf.seek(0)
        
        # Ensure crossOrigin is set to "anonymous" for images
        img = Image.open(buf).convert("RGBA")
        return img
    
    def spin(self, frames: int = 72, duration_ms: int = 50) -> Tuple[str, str]:
        """
        Generate a spinning wheel animation and determine the winner
        
        Args:
            frames: Number of frames in the animation
            duration_ms: Duration of each frame in milliseconds
            
        Returns:
            Tuple[str, str]: (winner_id, gif_path)
        """
        # Calculate final angle (multiple rotations for effect)
        final_angle = random.uniform(20 * math.pi, 25 * math.pi)
        frames_list = []
        
        # Generate frames
        for i in range(frames):
            progress = i / frames
            # Use easing function for natural slowdown
            eased_progress = 1 - (1 - progress) ** 4
            current_angle = final_angle * eased_progress
            frames_list.append(self.draw_frame(current_angle))
        
        # Determine winner based on final position
        final_position = (-final_angle - self.start_angle) % (2 * math.pi)
        winner = None
        epsilon = 1e-6
        
        for name, (start, end) in self.sector_angles.items():
            if (start - epsilon <= final_position <= end + epsilon) or \
               (start - epsilon <= final_position + 2 * math.pi <= end + epsilon):
                winner = name
                break
        
        # Save as GIF
        with tempfile.NamedTemporaryFile(suffix=".gif", delete=False) as temp:
            frames_list[0].save(
                temp.name,
                format='GIF',
                save_all=True,
                append_images=frames_list[1:],
                duration=duration_ms,
                loop=0,
                optimize=False,  # Disable optimization for better quality
                disposal=2  # Clear previous frame
            )
            temp_path = temp.name
        
        return winner, temp_path

class WheelGame:
    """
    Manages the Wheel of Fortune game logic
    """
    
    def __init__(self, session, redis_cache, payment_service):
        self.session = session
        self.redis_cache = redis_cache
        self.payment_service = payment_service
    
    async def get_participants(self) -> Dict[str, int]:
        """Get all users with tickets"""
        from database.models import User, GameParticipant, Game
        
        # Try to get from cache first
        cache_key = "wheel_game:participants"
        cached_data = await self.redis_cache.get(cache_key)
        if cached_data:
            return cached_data
        
        # Get from database
        result = await self.session.execute(
            select(GameParticipant).join(Game).where(
                Game.game_type == "wheel",
                Game.status == "active"
            )
        )
        participants = result.scalars().all()
        
        # Format as dictionary of user_id -> tickets
        participant_dict = {}
        for p in participants:
            participant_dict[str(p.user_id)] = p.tickets
        
        # Cache for 5 minutes
        await self.redis_cache.set(cache_key, participant_dict, 300)
        
        return participant_dict
    
    async def run_game(self, group_id: int) -> Tuple[bool, str, Optional[str]]:
        """
        Run the wheel game
        
        Args:
            group_id: Telegram group ID
            
        Returns:
            Tuple[bool, str, Optional[str]]: (success, message, winner_id)
        """
        gif_path = None
        
        try:
            # Get participants
            participants = await self.get_participants()
            
            if not participants:
                return False, "No participants with tickets", None
            
            # Create and spin the wheel
            wheel = FortuneWheel(participants)
            winner_id, temp_gif_path = wheel.spin()
            
            # Сохраняем путь к временному файлу
            gif_path = temp_gif_path
            
            # Get game details
            result = await self.session.execute(
                select(Game).where(
                    Game.group_id == group_id,
                    Game.game_type == "wheel",
                    Game.status == "active"
                )
            )
            game = result.scalar_one_or_none()
            
            if not game:
                return False, "No active wheel game found", None
            
            # Update game status
            game.status = "completed"
            game.end_time = datetime.utcnow()
            await self.session.commit()
            
            # Send prize to winner if configured
            if winner_id and game.prize_amount and game.prize_amount > 0:
                await self.payment_service.send_prize(
                    user_id=int(winner_id),
                    amount=game.prize_amount,
                    currency=game.prize_currency or "TON",
                    group_id=group_id,
                    transaction_type="prize"
                )
            
            # Копируем GIF в постоянное место, чтобы его можно было использовать после возврата
            permanent_dir = "wheel_results"
            os.makedirs(permanent_dir, exist_ok=True)
            permanent_gif_path = f"{permanent_dir}/{group_id}_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}.gif"
            
            try:
                shutil.copy2(gif_path, permanent_gif_path)
            except Exception as e:
                logger.error(f"Error copying GIF to permanent location: {e}")
                # Если копирование не удалось, вернем путь к временному файлу
                permanent_gif_path = gif_path
            
            return True, permanent_gif_path, winner_id
            
        except Exception as e:
            logger.error(f"Error running wheel game: {e}")
            return False, f"Error: {str(e)}", None
        
        finally:
            # Clean up temporary files
            if gif_path and os.path.exists(gif_path) and gif_path != permanent_gif_path:
                try:
                    os.remove(gif_path)
                except Exception as e:
                    logger.error(f"Error removing temporary file: {e}")

