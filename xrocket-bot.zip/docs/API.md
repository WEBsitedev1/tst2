# xRocket Bot API Documentation

## Overview

This document provides detailed information about the API endpoints available in the xRocket Bot. These endpoints allow external systems to interact with the bot and integrate with its functionality.

## Base URL

All API endpoints are relative to the base URL:

