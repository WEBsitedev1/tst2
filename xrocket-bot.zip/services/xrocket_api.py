import aiohttp
import logging
from typing import Dict, Any, Optional, List, Union

logger = logging.getLogger(__name__)

class XRocketAPI:
    def __init__(self, api_key: str, api_url: str):
        self.api_key = api_key
        self.api_url = api_url
        self.headers = {
            "Rocket-Pay-Key": api_key,
            "Content-Type": "application/json"
        }
    
    async def _make_request(
        self, 
        method: str, 
        endpoint: str, 
        data: Optional[Dict[str, Any]] = None,
        retry_count: int = 3
    ) -> Dict[str, Any]:
        """Make a request to the xRocket API with retries"""
        url = f"{self.api_url}{endpoint}"
        
        for attempt in range(retry_count):
            try:
                async with aiohttp.ClientSession() as session:
                    if method.lower() == "get":
                        async with session.get(url, headers=self.headers) as response:
                            response_data = await response.json()
                            if response.status in [200, 201]:
                                return response_data
                            logger.error(f"xRocket API error: {response.status} - {response_data}")
                    elif method.lower() == "post":
                        async with session.post(url, headers=self.headers, json=data) as response:
                            response_data = await response.json()
                            if response.status in [200, 201]:
                                return response_data
                            logger.error(f"xRocket API error: {response.status} - {response_data}")
            except Exception as e:
                logger.error(f"xRocket API request failed (attempt {attempt+1}/{retry_count}): {e}")
                if attempt == retry_count - 1:
                    raise
            
            # Wait before retry (exponential backoff)
            await asyncio.sleep(2 ** attempt)
        
        raise Exception("All retry attempts failed")
    
    async def get_app_info(self) -> Dict[str, Any]:
        """Get information about the application"""
        return await self._make_request("get", "/app/info")
    
    async def create_tg_invoice(
        self, 
        tg_user_id: int, 
        currency: str, 
        amount: float, 
        transfer_id: str, 
        description: str
    ) -> Dict[str, Any]:
        """Create a Telegram invoice"""
        data = {
            "tguserid": tg_user_id,
            "currency": currency,
            "amount": amount,
            "transferid": transfer_id,
            "description": description
        }
        return await self._make_request("post", "/tg-invoices", data)
    
    async def make_withdrawal(
        self,
        network: str,
        address: str,
        currency: str,
        amount: float,
        withdrawal_id: str,
        comment: Optional[str] = None
    ) -> Dict[str, Any]:
        """Make a withdrawal to an external wallet"""
        data = {
            "network": network,
            "address": address,
            "currency": currency,
            "amount": amount,
            "withdrawalid": withdrawal_id
        }
        if comment:
            data["comment"] = comment
        
        return await self._make_request("post", "/app/withdrawal", data)
    
    async def get_withdrawal_status(self, withdrawal_id: str) -> Dict[str, Any]:
        """Get withdrawal status"""
        return await self._make_request("get", f"/app/withdrawal/status/{withdrawal_id}")
    
    async def get_withdrawal_fees(self, currency: Optional[str] = None) -> Dict[str, Any]:
        """Get withdrawal fees"""
        endpoint = "/app/withdrawal/fees"
        if currency:
            endpoint += f"?currency={currency}"
        return await self._make_request("get", endpoint)
    
    async def create_multi_cheque(
        self,
        currency: str,
        cheque_per_user: float,
        users_number: int,
        ref_program: Optional[int] = None,
        password: Optional[str] = None,
        description: Optional[str] = None,
        send_notifications: bool = True,
        enabled: bool = True,
        telegram_resources_ids: Optional[List[str]] = None,
        for_premium: bool = False,
        linked_wallet: bool = False,
        disabled_languages: Optional[List[str]] = None,
        enabled_countries: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """Create a multi-cheque"""
        data = {
            "currency": currency,
            "chequePerUser": cheque_per_user,
            "usersNumber": users_number,
            "sendNotifications": send_notifications,
            "enabled": enabled,
            "forPremium": for_premium,
            "linkedWallet": linked_wallet
        }
        
        if ref_program is not None:
            data["refProgram"] = ref_program
        if password:
            data["password"] = password
        if description:
            data["description"] = description
        if telegram_resources_ids:
            data["telegramResourcesIds"] = telegram_resources_ids
        if disabled_languages:
            data["disabledLanguages"] = disabled_languages
        if enabled_countries:
            data["enabledCountries"] = enabled_countries
        
        return await self._make_request("post", "/multi-cheque", data)
    
    async def get_multi_cheques(self, limit: int = 100, offset: int = 0) -> Dict[str, Any]:
        """Get a list of multi-cheques"""
        return await self._make_request("get", f"/multi-cheque?limit={limit}&offset={offset}")
    
    async def get_multi_cheque(self, cheque_id: Union[int, str]) -> Dict[str, Any]:
        """Get information about a specific multi-cheque"""
        return await self._make_request("get", f"/multi-cheque/{cheque_id}")

