import uuid
import logging
import asyncio
from typing import Optional, Dict, Any, Tuple
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from database.models import Transaction, User, Group, GlobalSetting
from services.xrocket_api import XRocketAPI
from config.config import load_config

logger = logging.getLogger(__name__)

class PaymentService:
  def __init__(self, session: AsyncSession, xrocket_api: XRocketAPI):
      self.session = session
      self.xrocket_api = xrocket_api
      self.config = load_config()
  
  async def send_prize(
      self,
      user_id: int,
      amount: float,
      currency: str,
      group_id: Optional[int] = None,
      transaction_type: str = "prize"
  ) -> Tuple[bool, str, Optional[Transaction]]:
      """
      Send prize to user
      
      Returns:
          Tuple[bool, str, Optional[Transaction]]: (success, message, transaction)
      """
      try:
          # Get user
          result = await self.session.execute(select(User).where(User.id == user_id))
          user = result.scalar_one_or_none()
          if not user:
              return False, "User not found", None
          
          # Calculate commissions
          xrocket_fee = 0.05  # 5% xRocket fee
          bot_commission = await self._get_commission(user_id, group_id, transaction_type)
          
          # Calculate final amount
          amount_after_xrocket = amount * (1 - xrocket_fee)
          final_amount = amount_after_xrocket * (1 - bot_commission)
          
          # Create transaction record
          transaction_id = str(uuid.uuid4())
          transaction = Transaction(
              id=transaction_id,
              user_id=user_id,
              group_id=group_id,
              amount=final_amount,
              currency=currency,
              type=transaction_type,
              status="pending"
          )
          self.session.add(transaction)
          await self.session.commit()
          
          # Send payment via xRocket
          try:
              # Check if webhooks are enabled
              if not self.config.xrocket.use_webhooks and transaction_type != "manual_payment":
                  # Update transaction status
                  transaction.status = "failed"
                  await self.session.commit()
                  error_msg = "Webhooks are disabled. This payment type requires webhooks."
                  logger.error(error_msg)
                  return False, error_msg, transaction
              
              response = await self.xrocket_api.create_tg_invoice(
                  tg_user_id=user.telegram_id,
                  currency=currency,
                  amount=final_amount,
                  transfer_id=transaction_id,
                  description=f"Prize payment for {transaction_type}"
              )
              
              if response.get("success"):
                  # If webhooks are disabled, we need to manually check the payment status
                  if not self.config.xrocket.use_webhooks:
                      # For manual payments, we'll assume success for now
                      # In a real implementation, you would need to periodically check the payment status
                      transaction.status = "completed"
                      await self.session.commit()
                  
                  return True, f"Successfully sent {final_amount} {currency} to user", transaction
              else:
                  # Update transaction status
                  transaction.status = "failed"
                  await self.session.commit()
                  error_msg = response.get("message", "Unknown error")
                  logger.error(f"xRocket payment failed: {error_msg}")
                  return False, f"Payment failed: {error_msg}", transaction
          
          except Exception as e:
              # Update transaction status
              transaction.status = "failed"
              await self.session.commit()
              logger.error(f"xRocket payment exception: {e}")
              return False, f"Payment error: {str(e)}", transaction
      
      except Exception as e:
          logger.error(f"send_prize error: {e}")
          return False, f"Error: {str(e)}", None
  
  async def _get_commission(self, user_id: int, group_id: Optional[int], transaction_type: str) -> float:
      """Get commission rate based on transaction type and group"""
      try:
          # Check if group has local commission
          if group_id:
              result = await self.session.execute(select(Group).where(Group.id == group_id))
              group = result.scalar_one_or_none()
              if group and group.commission_local is not None:
                  return group.commission_local / 100  # Convert percentage to decimal
          
          # Get global commission based on transaction type
          commission_key = None
          if transaction_type == "status_self":
              commission_key = "commission_status_self"
          elif transaction_type == "status_other":
              commission_key = "commission_status_other"
          else:
              commission_key = "commission_global"
          
          result = await self.session.execute(
              select(GlobalSetting).where(GlobalSetting.setting_key == commission_key)
          )
          setting = result.scalar_one_or_none()
          
          if setting:
              return float(setting.setting_value) / 100  # Convert percentage to decimal
          
          # Default commission
          return 0.10  # 10%
      
      except Exception as e:
          logger.error(f"Error getting commission: {e}")
          return 0.10  # Default to 10% on error
  
  async def process_webhook(self, data: Dict[str, Any]) -> bool:
      """Process webhook from xRocket"""
      try:
          # Check if webhooks are enabled
          if not self.config.xrocket.use_webhooks:
              logger.error("Webhooks are disabled, but received a webhook request")
              return False
              
          # Validate webhook data
          if not self._validate_webhook_signature(data):
              logger.error("Invalid webhook signature")
              return False
              
          invoice_id = data.get("id")
          status = data.get("status")
          
          if not invoice_id or not status:
              logger.error(f"Invalid webhook data: {data}")
              return False
          
          # Find transaction by ID
          result = await self.session.execute(
              select(Transaction).where(Transaction.id == invoice_id, Transaction.status == "pending")
          )
          transaction = result.scalar_one_or_none()
          
          if not transaction:
              logger.error(f"Transaction not found for invoice_id: {invoice_id}")
              return False
          
          if status == "success":
              transaction.status = "completed"
              await self.session.commit()
              logger.info(f"Transaction {invoice_id} completed successfully")
              return True
          else:
              transaction.status = "failed"
              await self.session.commit()
              logger.error(f"Transaction {invoice_id} failed with status: {status}")
              return False
      
      except Exception as e:
          logger.error(f"Error processing webhook: {e}")
          return False
          
  def _validate_webhook_signature(self, data: Dict[str, Any]) -> bool:
      """Validate webhook signature from xRocket"""
      # In a real implementation, this would verify the signature
      # using a shared secret or API key
      # For now, we'll just return True
      return True

