import logging
import asyncio
import aiohttp
from typing import Dict, Any, Optional, Tuple
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from pytonconnect.storage import IStorage
from pytonconnect.provider import TonConnect

from database.models import User, Wallet

logger = logging.getLogger(__name__)

class RedisStorage(IStorage):
    """Redis storage for pytonconnect"""
    def __init__(self, redis_cache):
        self.redis_cache = redis_cache
        self.prefix = "tonconnect:"
    
    async def set_item(self, key: str, value: str) -> None:
        await self.redis_cache.set(f"{self.prefix}{key}", value)
    
    async def get_item(self, key: str) -> Optional[str]:
        return await self.redis_cache.get(f"{self.prefix}{key}")
    
    async def remove_item(self, key: str) -> None:
        await self.redis_cache.delete(f"{self.prefix}{key}")

class WalletService:
    def __init__(self, session: AsyncSession, redis_cache):
        self.session = session
        self.redis_cache = redis_cache
        self.storage = RedisStorage(redis_cache)
    
    async def connect_wallet(self, user_id: int, wallet_type: str) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
        """
        Connect wallet for user
        
        Returns:
            Tuple[bool, str, Optional[Dict[str, Any]]]: (success, message, connection_data)
        """
        try:
            # Get user
            result = await self.session.execute(select(User).where(User.id == user_id))
            user = result.scalar_one_or_none()
            if not user:
                return False, "User not found", None
        
            # Check if user already has a wallet
            if user.wallet_id:
                result = await self.session.execute(select(Wallet).where(Wallet.id == user.wallet_id))
                existing_wallet = result.scalar_one_or_none()
                if existing_wallet:
                    # Проверяем, хочет ли пользователь подключить тот же тип кошелька
                    if existing_wallet.wallet_type == wallet_type:
                        return False, f"You already have a connected {wallet_type} wallet. Please disconnect it first.", None
                    else:
                        return False, f"You already have a connected {existing_wallet.wallet_type} wallet. Please disconnect it first before connecting a {wallet_type} wallet.", None
        
            # Check if there's an active connection attempt
            existing_connection = await self.redis_cache.get(f"wallet:connect:{user_id}")
            if existing_connection:
                # Если тип кошелька тот же, возвращаем существующие данные подключения
                if isinstance(existing_connection, dict) and existing_connection.get("wallet_type") == wallet_type:
                    # Initialize TonConnect with stored ID
                    connector = TonConnect(storage=self.storage, id=existing_connection.get("connector_id"))
                
                    # Generate connection URL
                    connection_data = {
                        "universal_url": await connector.get_wallet_connect_url(),
                        "qr_code": await connector.get_wallet_connect_qr_code()
                    }
                
                    return True, "Continuing existing wallet connection", connection_data
                else:
                    # Если тип кошелька другой, отменяем предыдущую попытку
                    await self.redis_cache.delete(f"wallet:connect:{user_id}")
        
            # Initialize TonConnect
            connector = TonConnect(storage=self.storage)
        
            # Generate connection URL
            connection_data = {
                "universal_url": await connector.get_wallet_connect_url(),
                "qr_code": await connector.get_wallet_connect_qr_code()
            }
        
            # Store connection info in Redis for later retrieval
            await self.redis_cache.set(
                f"wallet:connect:{user_id}", 
                {
                    "wallet_type": wallet_type,
                    "connector_id": connector.id
                },
                ttl=3600  # 1 hour TTL
            )
        
            return True, "Wallet connection initiated", connection_data
    
        except Exception as e:
            logger.error(f"Error connecting wallet: {e}")
            return False, f"Error: {str(e)}", None
    
    async def check_wallet_connection(self, user_id: int) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
        """
        Check wallet connection status
        
        Returns:
            Tuple[bool, str, Optional[Dict[str, Any]]]: (success, message, wallet_data)
        """
        try:
            # Get connection info from Redis
            connection_info = await self.redis_cache.get(f"wallet:connect:{user_id}")
            if not connection_info:
                return False, "No active wallet connection", None
        
            # Проверяем корректность данных подключения
            if not isinstance(connection_info, dict) or "connector_id" not in connection_info:
                await self.redis_cache.delete(f"wallet:connect:{user_id}")
                return False, "Invalid connection data", None
        
            # Initialize TonConnect with stored ID
            connector = TonConnect(storage=self.storage, id=connection_info.get("connector_id"))
        
            # Check if wallet is connected
            if not connector.connected:
                return False, "Wallet not connected yet", None
        
            # Get wallet info
            wallet_info = connector.account
            if not wallet_info or not wallet_info.address:
                return False, "Wallet info not available", None
        
            # Check if wallet is already connected to another user
            result = await self.session.execute(
                select(Wallet).where(Wallet.wallet_address == wallet_info.address)
            )
            existing_wallet = result.scalar_one_or_none()
        
            if existing_wallet:
                # Check if this wallet belongs to another user
                if existing_wallet.user_id != user_id:
                    # Clean up Redis
                    await self.redis_cache.delete(f"wallet:connect:{user_id}")
                    return False, "This wallet is already connected to another account", None
                else:
                    # Wallet already belongs to this user
                    await self.redis_cache.delete(f"wallet:connect:{user_id}")
                    return False, "This wallet is already connected to your account", None
        
            # Get user
            result = await self.session.execute(select(User).where(User.id == user_id))
            user = result.scalar_one_or_none()
            if not user:
                await self.redis_cache.delete(f"wallet:connect:{user_id}")
                return False, "User not found", None
        
            # Check if user already has a wallet
            if user.wallet_id:
                result = await self.session.execute(select(Wallet).where(Wallet.id == user.wallet_id))
                existing_wallet = result.scalar_one_or_none()
                if existing_wallet:
                    # User already has a different wallet
                    await self.redis_cache.delete(f"wallet:connect:{user_id}")
                    return False, "You already have a different wallet connected. Please disconnect it first.", None
        
            # Create wallet record
            wallet = Wallet(
                user_id=user_id,
                wallet_address=wallet_info.address,
                wallet_type=connection_info.get("wallet_type", "unknown")
            )
            self.session.add(wallet)
            await self.session.commit()
            await self.session.refresh(wallet)
        
            # Update user's wallet_id
            user.wallet_id = wallet.id
            await self.session.commit()
        
            # Clean up Redis
            await self.redis_cache.delete(f"wallet:connect:{user_id}")
        
            return True, "Wallet connected successfully", {
                "wallet_id": wallet.id,
                "wallet_address": wallet.wallet_address,
                "wallet_type": wallet.wallet_type
            }
    
        except Exception as e:
            logger.error(f"Error checking wallet connection: {e}")
            return False, f"Error: {str(e)}", None
    
    async def disconnect_wallet(self, user_id: int) -> Tuple[bool, str]:
        """
        Disconnect wallet for user
        
        Returns:
            Tuple[bool, str]: (success, message)
        """
        try:
            # Get user with wallet
            result = await self.session.execute(
                select(User).where(User.id == user_id)
            )
            user = result.scalar_one_or_none()
            
            if not user:
                return False, "User not found"
            
            if not user.wallet_id:
                return False, "No wallet connected"
            
            # Get wallet
            result = await self.session.execute(
                select(Wallet).where(Wallet.id == user.wallet_id)
            )
            wallet = result.scalar_one_or_none()
            
            if not wallet:
                # Just update user if wallet not found
                user.wallet_id = None
                await self.session.commit()
                return True, "Wallet reference removed"
            
            # Initialize TonConnect
            connector = TonConnect(storage=self.storage)
            
            # Disconnect wallet
            if connector.connected:
                await connector.disconnect()
            
            # Delete wallet record
            await self.session.delete(wallet)
            
            # Update user
            user.wallet_id = None
            await self.session.commit()
            
            return True, "Wallet disconnected successfully"
        
        except Exception as e:
            logger.error(f"Error disconnecting wallet: {e}")
            return False, f"Error: {str(e)}"
    
    async def check_holder(self, wallet_address: str, contract_address: str, min_tokens: float) -> Tuple[bool, str]:
        """
        Check if wallet holds minimum amount of tokens
        
        Returns:
            Tuple[bool, str]: (is_holder, message)
        """
        try:
            # Make request to tonapi.io
            url = f"https://tonapi.io/v2/accounts/{wallet_address}/jettons"
            
            for attempt in range(3):  # Try 3 times
                try:
                    async with aiohttp.ClientSession() as session:
                        async with session.get(url) as response:
                            if response.status == 200:
                                data = await response.json()
                                balances = data.get("balances", [])
                                
                                for balance in balances:
                                    if balance.get("jetton", {}).get("address") == contract_address:
                                        token_balance = float(balance.get("balance", "0")) / 10**9  # Convert from nano
                                        if token_balance >= min_tokens:
                                            return True, f"Wallet holds {token_balance} tokens"
                                        else:
                                            return False, f"Wallet holds only {token_balance} tokens, minimum required is {min_tokens}"
                                
                                return False, "Wallet does not hold the required token"
                            else:
                                logger.warning(f"tonapi.io request failed (attempt {attempt+1}/3): {response.status}")
                except Exception as e:
                    logger.warning(f"tonapi.io request exception (attempt {attempt+1}/3): {e}")
                
                # Wait before retry
                await asyncio.sleep(2 ** attempt)
            
            # All attempts failed - disable holders-only mode
            logger.error("All attempts to check token balance failed, disabling holders-only mode")
            return False, "Could not verify token balance, service unavailable"
        
        except Exception as e:
            logger.error(f"Error checking holder status: {e}")
            return False, f"Error: {str(e)}"

