from fastapi import APIRouter, Request, Depends, HTTPException, Header
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from typing import Dict, Any, Optional
import hmac
import hashlib
import time
import json
import logging

from database.base import get_session_maker
from services.payments import PaymentService
from services.xrocket_api import XRocketAPI
from config.config import load_config

router = APIRouter()

logger = logging.getLogger(__name__)

async def get_db():
    """Get database session"""
    config = load_config()
    engine = create_async_engine(config.db)
    session_maker = get_session_maker(engine)

    async with session_maker() as session:
        yield session

async def get_xrocket_api():
    """Get xRocket API instance"""
    config = load_config()
    return XRocketAPI(config.xrocket.api_key, config.xrocket.api_url)

def verify_xrocket_signature(payload: bytes, signature: str, secret: str) -> bool:
    """
    Verify the signature from xRocket webhook
    
    Args:
        payload: Raw request body
        signature: Signature from X-Rocket-Signature header
        secret: Shared secret key
        
    Returns:
        bool: True if signature is valid
    """
    if not signature or not secret:
        return False
    
    # Проверка формата подписи
    try:
        # Проверяем, что подпись в шестнадцатеричном формате
        int(signature, 16)
        
        # Проверяем длину подписи (SHA-256 дает 64 символа в hex)
        if len(signature) != 64:
            logger.warning(f"Invalid signature length: {len(signature)}, expected 64")
            return False
    except ValueError:
        logger.warning("Signature is not a valid hexadecimal string")
        return False
    
    # Calculate expected signature
    expected_signature = hmac.new(
        secret.encode(),
        payload,
        hashlib.sha256
    ).hexdigest()
    
    # Compare signatures using constant-time comparison
    return hmac.compare_digest(expected_signature, signature)

@router.post("/webhook/xrocket")
async def xrocket_webhook(
    request: Request,
    x_rocket_signature: Optional[str] = Header(None),
    x_rocket_timestamp: Optional[str] = Header(None),
    db: AsyncSession = Depends(get_db),
    xrocket_api: XRocketAPI = Depends(get_xrocket_api)
):
    """Handle webhook from xRocket"""
    try:
        # Check if webhooks are enabled
        config = load_config()
        if not config.xrocket.use_webhooks:
            raise HTTPException(status_code=403, detail="Webhooks are disabled")
        
        # Get raw request body
        payload = await request.body()
        if not payload:
            raise HTTPException(status_code=400, detail="Empty request body")
        
        # Verify signature if webhook secret is configured
        if config.xrocket.webhook_secret:
            if not x_rocket_signature:
                raise HTTPException(status_code=401, detail="Missing signature header")
            
            # Verify timestamp to prevent replay attacks
            if x_rocket_timestamp:
                try:
                    timestamp = int(x_rocket_timestamp)
                    current_time = int(time.time())
                    # Reject requests older than 5 minutes
                    if current_time - timestamp > 300:
                        raise HTTPException(status_code=401, detail="Request too old")
                    # Reject requests from the future (with 30 seconds tolerance)
                    if timestamp - current_time > 30:
                        raise HTTPException(status_code=401, detail="Request timestamp is in the future")
                except ValueError:
                    raise HTTPException(status_code=401, detail="Invalid timestamp")
            else:
                raise HTTPException(status_code=401, detail="Missing timestamp header")
            
            # Verify signature
            if not verify_xrocket_signature(payload, x_rocket_signature, config.xrocket.webhook_secret):
                raise HTTPException(status_code=401, detail="Invalid signature")
        
        # Parse JSON data
        try:
            data = await request.json()
        except json.JSONDecodeError:
            raise HTTPException(status_code=400, detail="Invalid JSON data")
        
        # Validate webhook data
        if not data:
            raise HTTPException(status_code=400, detail="Empty webhook data")
            
        if "id" not in data:
            raise HTTPException(status_code=400, detail="Missing 'id' field in webhook data")
            
        if "status" not in data:
            raise HTTPException(status_code=400, detail="Missing 'status' field in webhook data")
        
        # Process webhook
        payment_service = PaymentService(db, xrocket_api)
        success = await payment_service.process_webhook(data)
        
        if success:
            return {"success": True, "message": "Webhook processed successfully"}
        else:
            return {"success": False, "message": "Failed to process webhook"}

    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except Exception as e:
        logger.error(f"Error processing webhook: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error processing webhook: {str(e)}")

