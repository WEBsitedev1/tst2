# Telegram Bot with xRocket Integration

This is a Telegram bot that integrates with the xRocket payment system, allowing users to play games, set statuses, and connect their TON wallets.

## Features

- **User Statuses**: Users can set custom statuses for themselves or others
- **Games**:
  - Emoji Game: Send emojis to win prizes
  - Wheel of Fortune: Spin the wheel to win prizes
  - Bank Game: Collect funds and play for the pot
  - PvP Game: Challenge other users to dice games
- **Wallet Integration**: Connect TON wallets via pytonconnect
- **Admin Panel**: Manage games, settings, and administrators
- **Developer Panel**: Configure global settings, manage groups, and control advertisements

## Installation

1. Clone the repository:

