from sqlalchemy.ext.asyncio import create_async_engine as _create_async_engine
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base

from config.config import DbConfig

Base = declarative_base()

def create_async_engine(db_config: DbConfig):
    """Create SQLAlchemy async engine"""
    return _create_async_engine(
        f"postgresql+asyncpg://{db_config.user}:{db_config.password}@{db_config.host}:{db_config.port}/{db_config.database}",
        echo=False,
        pool_size=20,
        max_overflow=0
    )

def get_session_maker(engine):
    """Create session maker for async SQLAlchemy engine"""
    return sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

