import uuid
from datetime import datetime
from sqlalchemy import Column, Integer, BigInteger, String, Float, Boolean, DateTime, ForeignKey, Enum, Text, UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from database.base import Base

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True)
    telegram_id = Column(BigInteger, unique=True, nullable=False)
    username = Column(String(32), nullable=True)
    wallet_id = Column(Integer, ForeignKey("wallets.id"), nullable=True)
    status_id = Column(Integer, ForeignKey("statuses.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    wallet = relationship("Wallet", back_populates="user")
    status = relationship("Status", foreign_keys=[status_id])
    
    def __repr__(self):
        return f"<User(id={self.id}, telegram_id={self.telegram_id}, username={self.username})>"

class Wallet(Base):
    __tablename__ = "wallets"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    wallet_address = Column(String(66), unique=True, nullable=False)
    wallet_type = Column(String(20), nullable=False)  # 'tonkeeper', 'ton_wallet', etc.
    connected_at = Column(DateTime, default=datetime.utcnow)
    
    user = relationship("User", back_populates="wallet")
    
    def __repr__(self):
        return f"<Wallet(id={self.id}, user_id={self.user_id}, wallet_address={self.wallet_address})>"

class Status(Base):
    __tablename__ = "statuses"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    target_user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    status_text = Column(String(50), nullable=False)
    price = Column(Float, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    target_user = relationship("User", foreign_keys=[target_user_id])
    
    def __repr__(self):
        return f"<Status(id={self.id}, user_id={self.user_id}, status_text={self.status_text})>"

class Group(Base):
    __tablename__ = "groups"
    
    id = Column(Integer, primary_key=True)
    telegram_group_id = Column(BigInteger, unique=True, nullable=False)
    group_name = Column(String(255), nullable=False)
    commission_local = Column(Float, nullable=True)
    holder_only_enabled = Column(Boolean, default=False)
    holder_contract_address = Column(String(66), nullable=True)
    holder_min_tokens = Column(Float, nullable=True)
    advertisement_enabled = Column(Boolean, default=True)
    is_blocked = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    games = relationship("Game", back_populates="group")
    advertisements = relationship("Advertisement", back_populates="group")
    
    def __repr__(self):
        return f"<Group(id={self.id}, telegram_group_id={self.telegram_group_id}, group_name={self.group_name})>"

class Advertisement(Base):
    __tablename__ = "advertisements"
    
    id = Column(Integer, primary_key=True)
    group_id = Column(Integer, ForeignKey("groups.id"), nullable=False)
    ad_text = Column(Text, nullable=False)
    media_url = Column(String(255), nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    group = relationship("Group", back_populates="advertisements")
    
    def __repr__(self):
        return f"<Advertisement(id={self.id}, group_id={self.group_id}, is_active={self.is_active})>"

class Game(Base):
    __tablename__ = "games"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    group_id = Column(Integer, ForeignKey("groups.id"), nullable=False)
    game_type = Column(Enum("emoji", "wheel", "bank", "pvp", name="game_type"), nullable=False)
    emoji_type = Column(String(10), nullable=True)
    infinite_mode = Column(Boolean, default=False)
    semi_wins_enabled = Column(Boolean, default=False)
    prize_amount = Column(Float, nullable=True)
    prize_currency = Column(String(10), nullable=True)
    attempts_limit = Column(Integer, nullable=True)
    custom_prize_type = Column(String(10), nullable=True)
    custom_prize_value = Column(Text, nullable=True)
    start_time = Column(DateTime, nullable=False, default=datetime.utcnow)
    end_time = Column(DateTime, nullable=True)
    status = Column(Enum("pending", "active", "completed", "cancelled", name="game_status"), default="pending")
    
    group = relationship("Group", back_populates="games")
    participants = relationship("GameParticipant", back_populates="game")
    
    def __repr__(self):
        return f"<Game(id={self.id}, group_id={self.group_id}, game_type={self.game_type}, status={self.status})>"

class GameParticipant(Base):
    __tablename__ = "game_participants"
    
    id = Column(Integer, primary_key=True)
    game_id = Column(UUID(as_uuid=True), ForeignKey("games.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    attempts_used = Column(Integer, default=0)
    score = Column(Integer, nullable=True)
    tickets = Column(Integer, default=1)
    joined_at = Column(DateTime, default=datetime.utcnow)
    
    game = relationship("Game", back_populates="participants")
    user = relationship("User")
    
    def __repr__(self):
        return f"<GameParticipant(id={self.id}, game_id={self.game_id}, user_id={self.user_id})>"

class Transaction(Base):
    __tablename__ = "transactions"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    group_id = Column(Integer, ForeignKey("groups.id"), nullable=True)
    amount = Column(Float, nullable=False)
    currency = Column(String(10), nullable=False)
    type = Column(Enum("status_self", "status_other", "game_entry", "prize", "refund", name="transaction_type"), nullable=False)
    status = Column(Enum("pending", "completed", "failed", name="transaction_status"), default="pending")
    created_at = Column(DateTime, default=datetime.utcnow)
    
    user = relationship("User")
    group = relationship("Group")
    
    def __repr__(self):
        return f"<Transaction(id={self.id}, user_id={self.user_id}, amount={self.amount}, status={self.status})>"

class PvpSession(Base):
    __tablename__ = "pvp_sessions"
    
    id = Column(Integer, primary_key=True)
    challenger_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    opponent_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    game_id = Column(UUID(as_uuid=True), ForeignKey("games.id"), nullable=False)
    challenger_attempts = Column(Integer, default=0)
    opponent_attempts = Column(Integer, default=0)
    challenger_score = Column(Integer, default=0)
    opponent_score = Column(Integer, default=0)
    result = Column(Enum("challenger_win", "opponent_win", "draw", "pending", name="pvp_result"), default="pending")
    created_at = Column(DateTime, default=datetime.utcnow)
    
    challenger = relationship("User", foreign_keys=[challenger_id])
    opponent = relationship("User", foreign_keys=[opponent_id])
    game = relationship("Game")
    
    def __repr__(self):
        return f"<PvpSession(id={self.id}, challenger_id={self.challenger_id}, opponent_id={self.opponent_id}, result={self.result})>"

class GlobalSetting(Base):
    __tablename__ = "global_settings"
    
    setting_key = Column(String(50), primary_key=True)
    setting_value = Column(Text, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<GlobalSetting(setting_key={self.setting_key}, setting_value={self.setting_value})>"

class Log(Base):
    __tablename__ = "logs"
    
    id = Column(Integer, primary_key=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    level = Column(Enum("info", "warning", "error", name="log_level"), nullable=False)
    message = Column(Text, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    group_id = Column(Integer, ForeignKey("groups.id"), nullable=True)
    
    user = relationship("User")
    group = relationship("Group")
    
    def __repr__(self):
        return f"<Log(id={self.id}, level={self.level}, message={self.message})>"

