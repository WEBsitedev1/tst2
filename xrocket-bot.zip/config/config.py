import os
from dataclasses import dataclass
from typing import Optional, List
from dotenv import load_dotenv

@dataclass
class TgBot:
    token: str
    dev_ids: List[int]
    use_redis: bool

@dataclass
class DbConfig:
    host: str
    port: int
    password: str
    user: str
    database: str

@dataclass
class RedisConfig:
    host: str
    port: int
    password: Optional[str]
    db: int

@dataclass
class XRocketConfig:
    api_key: str
    api_url: str
    use_webhooks: bool
    webhook_secret: Optional[str]

@dataclass
class StorageConfig:
    use_json: bool
    json_data_path: str

@dataclass
class Config:
    tg_bot: TgBot
    db: DbConfig
    redis: RedisConfig
    xrocket: XRocketConfig
    storage: StorageConfig

def load_config() -> Config:
    load_dotenv()

    return Config(
        tg_bot=TgBot(
            token=os.getenv("BOT_TOKEN"),
            dev_ids=list(map(int, os.getenv("DEV_IDS", "").split(","))),
            use_redis=os.getenv("USE_REDIS", "False").lower() in ("true", "1", "t")
        ),
        db=DbConfig(
            host=os.getenv("DB_HOST", "localhost"),
            port=int(os.getenv("DB_PORT", 5432)),
            password=os.getenv("DB_PASS", ""),
            user=os.getenv("DB_USER", "postgres"),
            database=os.getenv("DB_NAME", "telegram_bot")
        ),
        redis=RedisConfig(
            host=os.getenv("REDIS_HOST", "localhost"),
            port=int(os.getenv("REDIS_PORT", 6379)),
            password=os.getenv("REDIS_PASSWORD", None),
            db=int(os.getenv("REDIS_DB", 0))
        ),
        xrocket=XRocketConfig(
            api_key=os.getenv("XROCKET_API_KEY", ""),
            api_url=os.getenv("XROCKET_API_URL", "https://pay.ton-rocket.com/api"),
            use_webhooks=os.getenv("XROCKET_USE_WEBHOOKS", "True").lower() in ("true", "1", "t"),
            webhook_secret=os.getenv("XROCKET_WEBHOOK_SECRET")
        ),
        storage=StorageConfig(
            use_json=os.getenv("USE_JSON_STORAGE", "False").lower() in ("true", "1", "t"),
            json_data_path=os.getenv("JSON_DATA_PATH", "data")
        )
    )

