import pytest
import os
import asyncio
from unittest.mock import AsyncMock, MagicMock, patch
import tempfile

from games.wheel_game import FortuneWheel, WheelGame

@pytest.fixture
def mock_session():
    session = AsyncMock()
    session.execute = AsyncMock()
    session.commit = AsyncMock()
    return session

@pytest.fixture
def mock_redis_cache():
    cache = AsyncMock()
    return cache

@pytest.fixture
def mock_payment_service():
    service = AsyncMock()
    return service

@pytest.fixture
def wheel_game(mock_session, mock_redis_cache, mock_payment_service):
    return WheelGame(mock_session, mock_redis_cache, mock_payment_service)

@pytest.mark.asyncio
async def test_get_participants(wheel_game, mock_session):
    # Mock the database response
    mock_session.execute.return_value.fetchall.return_value = [
        (1, 3),  # user_id, tickets
        (2, 1),
        (3, 5)
    ]
    
    # Get participants
    participants = await wheel_game.get_participants()
    
    # Verify results
    assert participants == {"1": 3, "2": 1, "3": 5}
    assert mock_session.execute.called

@pytest.mark.asyncio
async def test_run_game_no_participants(wheel_game, mock_session):
    # Mock empty participants list
    wheel_game.get_participants = AsyncMock(return_value={})
    
    # Run game with no participants
    success, message, winner_id = await wheel_game.run_game(123)
    
    # Verify results
    assert success is False
    assert "No participants" in message
    assert winner_id is None

@pytest.mark.asyncio
async def test_run_game_with_participants(wheel_game, mock_session):
    # Mock participants
    wheel_game.get_participants = AsyncMock(return_value={"1": 3, "2": 1})
    
    # Mock FortuneWheel.spin
    with patch('games.wheel_game.FortuneWheel') as MockFortuneWheel:
        mock_wheel = MockFortuneWheel.return_value
        
        # Create a temporary file for testing
        with tempfile.NamedTemporaryFile(delete=False) as temp:
            temp_path = temp.name
        
        mock_wheel.spin.return_value = ("1", temp_path)
        
        # Run game
        success, message, winner_id = await wheel_game.run_game(123)
        
        # Verify results
        assert success is True
        assert message == temp_path
        assert winner_id == "1"
        
        # Verify tickets were reset
        assert mock_session.execute.called
        assert mock_session.commit.called
        
        # Clean up
        if os.path.exists(temp_path):
            os.remove(temp_path)

def test_fortune_wheel_init():
    # Test wheel initialization
    sectors = {"user1": 3, "user2": 1, "user3": 5}
    wheel = FortuneWheel(sectors)
    
    # Verify wheel properties
    assert wheel.sectors == sectors
    assert wheel.sector_count == 3
    assert wheel.total_cells == 9
    assert len(wheel.sector_colors) == 3
    assert len(wheel.sector_angles) == 3

def test_fortune_wheel_spin():
    # Test wheel spinning
    sectors = {"user1": 3, "user2": 1, "user3": 5}
    wheel = FortuneWheel(sectors)
    
    # Spin the wheel
    winner, gif_path = wheel.spin(frames=10)  # Use fewer frames for testing
    
    # Verify results
    assert winner in sectors
    assert os.path.exists(gif_path)
    assert gif_path.endswith(".gif")
    
    # Clean up
    if os.path.exists(gif_path):
        os.remove(gif_path)

