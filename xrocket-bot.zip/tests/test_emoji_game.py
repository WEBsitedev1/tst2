import pytest
import asyncio
from unittest.mock import AsyncMock, MagicMock, patch
from sqlalchemy.ext.asyncio import AsyncSession

from games.emoji_game import EmojiGame
from database.models import Game, GameParticipant, User, Group

@pytest.fixture
def mock_session():
    session = AsyncMock(spec=AsyncSession)
    session.commit = AsyncMock()
    session.rollback = AsyncMock()
    return session

@pytest.fixture
def mock_payment_service():
    service = AsyncMock()
    service.send_prize = AsyncMock(return_value=(True, "Prize sent", None))
    return service

@pytest.fixture
def emoji_game(mock_session, mock_payment_service):
    return EmojiGame(mock_session, mock_payment_service)

@pytest.mark.asyncio
async def test_start_game(emoji_game, mock_session):
    # Mock the query result for existing games
    mock_session.execute.return_value.scalar_one_or_none.return_value = None
    
    # Test starting a game
    success, message = await emoji_game.start_game(
        group_id=123,
        emoji_type="🎰",
        settings={
            "infinite_game": True,
            "semi_win": True,
            "prize_amount": 1.0,
            "coin_selection": "TON",
            "attempts_limit": 3
        }
    )
    
    # Verify results
    assert success is True
    assert "started" in message
    assert mock_session.add.called
    assert mock_session.commit.called

@pytest.mark.asyncio
async def test_start_game_already_running(emoji_game, mock_session):
    # Mock an existing game
    mock_game = MagicMock()
    mock_session.execute.return_value.scalar_one_or_none.return_value = mock_game
    
    # Test starting a game when one is already running
    success, message = await emoji_game.start_game(
        group_id=123,
        emoji_type="🎰",
        settings={}
    )
    
    # Verify results
    assert success is False
    assert "already running" in message
    assert not mock_session.add.called

@pytest.mark.asyncio
async def test_process_emoji_winner(emoji_game, mock_session, mock_payment_service):
    # Mock game and participant
    mock_game = MagicMock()
    mock_game.emoji_type = "🎰"
    mock_game.semi_wins_enabled = True
    mock_game.infinite_mode = False
    mock_game.prize_amount = 1.0
    mock_game.prize_currency = "TON"
    
    mock_participant = MagicMock()
    mock_participant.attempts_used = 0
    
    # Set up mock query results
    mock_session.execute.side_effect = [
        AsyncMock(scalar_one_or_none=AsyncMock(return_value=mock_game)),
        AsyncMock(scalar_one_or_none=AsyncMock(return_value=mock_participant))
    ]
    
    # Test processing a winning emoji
    success, message, is_winner = await emoji_game.process_emoji(
        group_id=123,
        user_id=456,
        emoji="🎰",
        value=64  # Winning value for 🎰
    )
    
    # Verify results
    assert success is True
    assert is_winner is True
    assert mock_payment_service.send_prize.called
    assert mock_session.commit.called
    assert mock_participant.attempts_used == 1
    assert mock_game.status == "completed"  # Game should end since it's not infinite

@pytest.mark.asyncio
async def test_process_emoji_not_winner(emoji_game, mock_session, mock_payment_service):
    # Mock game and participant
    mock_game = MagicMock()
    mock_game.emoji_type = "🎰"
    mock_game.semi_wins_enabled = False
    mock_game.infinite_mode = True
    
    mock_participant = MagicMock()
    mock_participant.attempts_used = 0
    
    # Set up mock query results
    mock_session.execute.side_effect = [
        AsyncMock(scalar_one_or_none=AsyncMock(return_value=mock_game)),
        AsyncMock(scalar_one_or_none=AsyncMock(return_value=mock_participant))
    ]
    
    # Test processing a non-winning emoji
    success, message, is_winner = await emoji_game.process_emoji(
        group_id=123,
        user_id=456,
        emoji="🎰",
        value=10  # Non-winning value for 🎰
    )
    
    # Verify results
    assert success is True
    assert is_winner is False
    assert not mock_payment_service.send_prize.called
    assert mock_session.commit.called
    assert mock_participant.attempts_used == 1
    assert mock_game.status != "completed"  # Game should continue since it's infinite

