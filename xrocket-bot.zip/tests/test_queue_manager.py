import pytest
import asyncio
from unittest.mock import AsyncMock, MagicMock
from utils.queue_manager import QueueManager

@pytest.fixture
def queue_manager():
    return QueueManager(max_queue_size=5)

@pytest.mark.asyncio
async def test_add_task(queue_manager):
    # Create a mock function
    mock_func = AsyncMock()
    
    # Add task to queue
    result = await queue_manager.add_task("game_actions", mock_func, "arg1", "arg2", kwarg1="value1")
    
    # Check result
    assert result is True
    
    # Check queue size
    assert queue_manager.get_queue_sizes()["game_actions"] == 1

@pytest.mark.asyncio
async def test_queue_full(queue_manager):
    # Create a mock function
    mock_func = AsyncMock()
    
    # Fill the queue
    for i in range(5):
        await queue_manager.add_task("game_actions", mock_func)
    
    # Try to add one more task
    result = await queue_manager.add_task("game_actions", mock_func)
    
    # Check result
    assert result is False
    
    # Check queue size
    assert queue_manager.get_queue_sizes()["game_actions"] == 5

@pytest.mark.asyncio
async def test_worker_processes_tasks(queue_manager):
    # Create a mock function
    mock_func = AsyncMock()
    
    # Start workers
    await queue_manager.start_workers()
    
    # Add task to queue
    await queue_manager.add_task("game_actions", mock_func, "arg1", "arg2", kwarg1="value1")
    
    # Wait for task to be processed
    await asyncio.sleep(0.1)
    
    # Check if function was called
    mock_func.assert_called_once_with("arg1", "arg2", kwarg1="value1")
    
    # Stop workers
    await queue_manager.stop_workers()

@pytest.mark.asyncio
async def test_save_and_restore_state(queue_manager):
    # Start workers
    await queue_manager.start_workers()
    
    # Add some tasks and process them
    mock_func = AsyncMock()
    await queue_manager.add_task("game_actions", mock_func)
    await queue_manager.add_task("admin_commands", mock_func)
    
    # Wait for tasks to be processed
    await asyncio.sleep(0.1)
    
    # Save state
    state = await queue_manager.save_state()
    
    # Check state
    assert "stats" in state
    assert state["stats"]["game_actions"] == 1
    assert state["stats"]["admin_commands"] == 1
    
    # Create new queue manager
    new_queue_manager = QueueManager()
    
    # Restore state
    await new_queue_manager.restore_state(state)
    
    # Check restored stats
    assert new_queue_manager.get_stats()["game_actions"] == 1
    assert new_queue_manager.get_stats()["admin_commands"] == 1
    
    # Stop workers
    await queue_manager.stop_workers()
    await new_queue_manager.stop_workers()

