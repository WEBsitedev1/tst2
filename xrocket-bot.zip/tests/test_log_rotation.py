import pytest
import asyncio
import os
from datetime import datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from utils.log_rotation import LogRotationManager

@pytest.fixture
def mock_session_maker():
    session = AsyncMock()
    session.execute = AsyncMock()
    session.commit = AsyncMock()
    session.rollback = AsyncMock()
    
    session_maker = MagicMock()
    session_maker.return_value.__aenter__.return_value = session
    session_maker.return_value.__aexit__.return_value = None
    
    return session_maker

@pytest.mark.asyncio
async def test_rotate_logs_db(mock_session_maker):
    # Create log rotation manager
    log_rotation = LogRotationManager(mock_session_maker, retention_days=14)
    
    # Mock database query results
    mock_session = mock_session_maker().__aenter__()
    mock_session.execute.return_value.scalar.return_value = 10  # 10 logs to delete
    
    # Run log rotation
    await log_rotation._rotate_logs()
    
    # Check if delete query was executed
    assert mock_session.execute.called
    assert mock_session.commit.called
    
    # Check stats
    assert log_rotation.get_stats()["deleted_count"] == 10
    assert log_rotation.get_stats()["total_runs"] == 1

@pytest.mark.asyncio
async def test_rotate_logs_json(mock_session_maker):
    # Create temporary directory for JSON files
    import tempfile
    import json
    import shutil
    
    temp_dir = tempfile.mkdtemp()
    try:
        # Create global directory
        os.makedirs(os.path.join(temp_dir, "global"))
        
        # Create logs file with old and new logs
        logs_file = os.path.join(temp_dir, "global", "logs.json")
        logs_data = {
            "1": {
                "timestamp": (datetime.utcnow() - timedelta(days=20)).isoformat(),
                "message": "Old log"
            },
            "2": {
                "timestamp": datetime.utcnow().isoformat(),
                "message": "New log"
            }
        }
        
        with open(logs_file, "w") as f:
            json.dump(logs_data, f)
        
        # Create log rotation manager with JSON storage
        mock_session = mock_session_maker().__aenter__()
        mock_session._read_json_file = AsyncMock(return_value=logs_data)
        mock_session._write_json_file = AsyncMock()
        mock_session.data_path = temp_dir
        
        log_rotation = LogRotationManager(mock_session_maker, retention_days=14)
        
        # Run log rotation
        await log_rotation._rotate_logs()
        
        # Check if write was called with only the new log
        expected_data = {
            "2": {
                "timestamp": logs_data["2"]["timestamp"],
                "message": "New log"
            }
        }
        mock_session._write_json_file.assert_called_once()
        assert mock_session._write_json_file.call_args[0][1] == expected_data
        
        # Check stats
        assert log_rotation.get_stats()["deleted_count"] == 1
        assert log_rotation.get_stats()["total_runs"] == 1
    
    finally:
        # Clean up
        shutil.rmtree(temp_dir)

@pytest.mark.asyncio
async def test_start_stop(mock_session_maker):
    # Create log rotation manager
    log_rotation = LogRotationManager(mock_session_maker, retention_days=14)
    
    # Start log rotation
    await log_rotation.start(interval_hours=0.01)  # Very short interval for testing
    
    # Check if running
    assert log_rotation.running is True
    assert log_rotation.task is not None
    
    # Wait for at least one run
    await asyncio.sleep(0.02)
    
    # Stop log rotation
    await log_rotation.stop()
    
    # Check if stopped
    assert log_rotation.running is False
    assert log_rotation.task is None or log_rotation.task.done()

