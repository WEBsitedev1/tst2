import pytest
import asyncio
from unittest.mock import AsyncMock, MagicMock, patch
from sqlalchemy.ext.asyncio import AsyncSession

from database.models import User, Group, Game, GameParticipant, Transaction
from services.payments import PaymentService
from services.wallet_service import WalletService
from games.emoji_game import EmojiGame
from games.wheel_game import WheelGame

@pytest.fixture
async def setup_db():
    """Setup test database and return session"""
    from database.base import create_async_engine, get_session_maker, Base
    
    # Use in-memory SQLite for testing
    engine = create_async_engine({
        "host": ":memory:",
        "port": 0,
        "password": "",
        "user": "",
        "database": ""
    })
    
    # Create tables
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    # Create session
    session_maker = get_session_maker(engine)
    async with session_maker() as session:
        yield session
    
    # Drop tables
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)

@pytest.fixture
def mock_xrocket_api():
    api = AsyncMock()
    api.create_tg_invoice.return_value = {"success": True, "data": {"id": "test_invoice", "url": "https://example.com"}}
    return api

@pytest.fixture
def mock_redis_cache():
    cache = AsyncMock()
    return cache

@pytest.mark.asyncio
async def test_emoji_game_integration(setup_db, mock_xrocket_api, mock_redis_cache):
    session = setup_db
    
    # Create payment service
    payment_service = PaymentService(session, mock_xrocket_api)
    
    # Create emoji game
    emoji_game = EmojiGame(session, payment_service)
    
    # Create test user
    user = User(telegram_id=123456789, username="testuser")
    session.add(user)
    
    # Create test group
    group = Group(
        telegram_group_id=-100123456789,
        group_name="Test Group",
        commission_local=5.0
    )
    session.add(group)
    await session.commit()
    await session.refresh(user)
    await session.refresh(group)
    
    # Start emoji game
    success, message = await emoji_game.start_game(
        group_id=group.id,
        emoji_type="🎰",
        settings={
            "infinite_game": False,
            "semi_win": True,
            "prize_amount": 1.0,
            "coin_selection": "TON",
            "attempts_limit": 3
        }
    )
    
    assert success is True
    
    # Get the game
    result = await session.execute("SELECT * FROM games WHERE group_id = :group_id", {"group_id": group.id})
    game = result.fetchone()
    
    # Add participant
    success, message = await emoji_game.add_participant(game.id, user.id)
    assert success is True
    
    # Process winning emoji
    success, message, is_winner = await emoji_game.process_emoji(
        group_id=group.id,
        user_id=user.id,
        emoji="🎰",
        value=64  # Winning value
    )
    
    assert success is True
    assert is_winner is True
    
    # Verify transaction was created
    result = await session.execute("SELECT * FROM transactions WHERE user_id = :user_id", {"user_id": user.id})
    transaction = result.fetchone()
    assert transaction is not None
    assert transaction.status == "completed"
    
    # Verify game was completed
    result = await session.execute("SELECT * FROM games WHERE id = :game_id", {"game_id": game.id})
    updated_game = result.fetchone()
    assert updated_game.status == "completed"

@pytest.mark.asyncio
async def test_wallet_service_integration(setup_db, mock_redis_cache):
    session = setup_db
    
    # Create wallet service
    wallet_service = WalletService(session, mock_redis_cache)
    
    # Create test user
    user = User(telegram_id=123456789, username="testuser")
    session.add(user)
    await session.commit()
    await session.refresh(user)
    
    # Mock TonConnect
    with patch('services.wallet_service.TonConnect') as MockTonConnect:
        mock_connector = MockTonConnect.return_value
        mock_connector.connected = True
        mock_connector.account = MagicMock(address="EQB1capxb3R-VLA3HLDVB1Rx6CHpWQA_7MOg1hqL2Cw2x_dz")
        
        # Set up connection info in Redis
        await mock_redis_cache.set(
            f"wallet:connect:{user.id}",
            {"wallet_type": "Tonkeeper", "connector_id": "test_id"}
        )
        
        # Check wallet connection
        success, message, wallet_data = await wallet_service.check_wallet_connection(user.id)
        
        assert success is True
        assert "connected successfully" in message
        assert wallet_data["wallet_address"] == "EQB1capxb3R-VLA3HLDVB1Rx6CHpWQA_7MOg1hqL2Cw2x_dz"
        
        # Verify wallet was created in database
        result = await session.execute("SELECT * FROM wallets WHERE user_id = :user_id", {"user_id": user.id})
        wallet = result.fetchone()
        assert wallet is not None
        assert wallet.wallet_address == "EQB1capxb3R-VLA3HLDVB1Rx6CHpWQA_7MOg1hqL2Cw2x_dz"
        assert wallet.wallet_type == "Tonkeeper"

