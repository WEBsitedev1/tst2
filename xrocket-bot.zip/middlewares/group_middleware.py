from typing import Callable, Dict, Any, Awaitable
from aiogram import BaseMiddleware
from aiogram.types import Update, Message, Chat, ChatMemberUpdated
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import sessionmaker
from datetime import datetime
import logging

from database.models import Group
from utils.redis_cache import RedisCache

logger = logging.getLogger(__name__)

class GroupMiddleware(BaseMiddleware):
    def __init__(self, session_maker: sessionmaker, redis_cache: RedisCache):
        self.session_maker = session_maker
        self.redis_cache = redis_cache
        super().__init__()
    
    async def __call__(
        self,
        handler: Callable[[Update, Dict[str, Any]], Awaitable[Any]],
        event: Update,
        data: Dict[str, Any]
    ) -> Any:
        # Check if the update is from a group
        chat = None
        if event.message:
            chat = event.message.chat
        elif event.callback_query and event.callback_query.message:
            chat = event.callback_query.message.chat
        elif event.my_chat_member:
            chat = event.my_chat_member.chat
        
        if chat and chat.type in ["group", "supergroup"]:
            # Check if bot is blocked in this group
            group_info = await self._get_group_info(chat)
            if group_info.get("blocked", False):
                # If this is a my_chat_member update, still process it
                if not event.my_chat_member:
                    return
            
            # Check if bot has necessary permissions
            if not await self._check_bot_permissions(chat.id):
                # Add warning to data
                data["no_permissions"] = True
            
            # Add group info to data
            data["group_info"] = group_info
            
            # Add language to data
            data["language"] = "ru"  # Default language
        
        # Continue processing
        return await handler(event, data)
    
    async def _get_group_info(self, chat: Chat) -> Dict[str, Any]:
        # Try to get from cache first
        cache_key = f"group:settings:{chat.id}"
        group_info = await self.redis_cache.get(cache_key)
        
        if not group_info:
            # Get from database or JSON storage
            async with self.session_maker() as session:
                # Check if we're using JSON storage
                if hasattr(session, '_read_json_file'):
                    # JSON storage implementation
                    group_dir = session.data_path / "groups" / str(chat.id)
                    if group_dir.exists():
                        settings_file = group_dir / "settings.json"
                        if settings_file.exists():
                            group_info = await session._read_json_file(settings_file)
                    
                    if not group_info:
                        # Create new group
                        group_info = {
                            "id": str(chat.id),
                            "telegram_group_id": chat.id,
                            "group_name": chat.title,
                            "commission_local": None,
                            "holder_only_enabled": False,
                            "holder_contract_address": None,
                            "holder_min_tokens": None,
                            "advertisement_enabled": True,
                            "is_blocked": False,
                            "updated_at": datetime.now().isoformat()
                        }
                        
                        # Create group directory
                        group_dir.mkdir(parents=True, exist_ok=True)
                        
                        # Save group settings
                        await session._write_json_file(settings_file, group_info)
                    elif group_info.get("group_name") != chat.title:
                        # Update group name if changed
                        group_info["group_name"] = chat.title
                        group_info["updated_at"] = datetime.now().isoformat()
                        
                        # Save group settings
                        await session._write_json_file(settings_file, group_info)
                else:
                    # Database implementation
                    result = await session.execute(
                        select(Group).where(Group.telegram_group_id == chat.id)
                    )
                    group = result.scalar_one_or_none()
                    
                    if not group:
                        # Create new group
                        group = Group(
                            telegram_group_id=chat.id,
                            group_name=chat.title
                        )
                        session.add(group)
                        await session.commit()
                        await session.refresh(group)
                    elif group.group_name != chat.title:
                        # Update group name if changed
                        group.group_name = chat.title
                        await session.commit()
                    
                    # Convert to dict
                    group_info = {
                        "id": group.id,
                        "telegram_group_id": group.telegram_group_id,
                        "group_name": group.group_name,
                        "commission_local": group.commission_local,
                        "holder_only_enabled": group.holder_only_enabled,
                        "holder_contract_address": group.holder_contract_address,
                        "holder_min_tokens": group.holder_min_tokens,
                        "advertisement_enabled": group.advertisement_enabled,
                        "is_blocked": group.is_blocked,
                        "updated_at": group.updated_at.isoformat() if group.updated_at else None
                    }
            
            # Cache for 1 hour
            await self.redis_cache.set(cache_key, group_info, 3600)
        
        return group_info
    
    async def _check_bot_permissions(self, chat_id: int) -> bool:
        """Check if bot has necessary permissions in the group"""
        try:
            from aiogram import Bot
            bot = Bot.get_current()
            
            # Get bot member info
            bot_member = await bot.get_chat_member(chat_id, (await bot.get_me()).id)
            
            # Get chat administrators to check if bot is admin
            chat_admins = await bot.get_chat_administrators(chat_id)
            is_admin = any(admin.user.id == bot.id for admin in chat_admins)
            
            # Check if bot has necessary permissions
            has_permissions = (
                bot_member.status == "administrator" and
                bot_member.can_send_messages and
                bot_member.can_delete_messages and
                bot_member.can_restrict_members
            )
            
            return is_admin and has_permissions
        except Exception as e:
            logger.error(f"Error checking bot permissions: {e}")
            # If we can't check permissions, assume we don't have them
            return False

