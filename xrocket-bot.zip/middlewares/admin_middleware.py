from typing import Callable, Dict, Any, Awaitable
from aiogram import BaseMiddleware
from aiogram.types import Update, Message, Chat
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import sessionmaker
from datetime import datetime
import logging

from database.models import Group
from utils.redis_cache import RedisCache

logger = logging.getLogger(__name__)

class AdminMiddleware(BaseMiddleware):
    def __init__(self, session_maker: sessionmaker, redis_cache: RedisCache):
        self.session_maker = session_maker
        self.redis_cache = redis_cache
        super().__init__()
    
    async def __call__(
        self,
        handler: Callable[[Update, Dict[str, Any]], Awaitable[Any]],
        event: Update,
        data: Dict[str, Any]
    ) -> Any:
        # Check if this is an admin command
        if event.message and event.message.text and event.message.text.startswith("/admin"):
            # Check if user is an admin
            is_admin = await self._check_admin_rights(event.message.chat.id, event.message.from_user.id)
            data["is_admin"] = is_admin
            
            if not is_admin:
                # If not admin, respond with error message
                await event.message.answer("⚠️ У вас нет прав администратора для использования этой команды.")
                return
        
        # Continue processing
        return await handler(event, data)
    
    async def _check_admin_rights(self, chat_id: int, user_id: int) -> bool:
        """Check if user is an admin of the group"""
        try:
            from aiogram import Bot
            bot = Bot.get_current()
        
            # Try to get from cache first
            cache_key = f"admin:rights:{chat_id}:{user_id}"
            is_admin = await self.redis_cache.get(cache_key)
        
            if is_admin is not None:
                return is_admin
        
            try:
                # Get chat administrators
                chat_admins = await bot.get_chat_administrators(chat_id)
            
                # Check if user is in the list of administrators
                is_admin = any(admin.user.id == user_id for admin in chat_admins)
            
                # Cache result for 5 minutes
                await self.redis_cache.set(cache_key, is_admin, 300)
            
                return is_admin
            except Exception as e:
                # Если бот не может получить список администраторов, проверяем, является ли пользователь владельцем бота
                if user_id == (await bot.get_me()).id:
                    return True
                
                # Проверяем, является ли пользователь разработчиком
                from config.config import load_config
                config = load_config()
                if user_id in config.tg_bot.dev_ids:
                    logger.warning(f"Could not get admin list, but user {user_id} is a developer")
                    return True
                
                logger.error(f"Error getting chat administrators: {e}")
                # Кэшируем отрицательный результат на короткое время
                await self.redis_cache.set(cache_key, False, 60)
                return False
        except Exception as e:
            logger.error(f"Error checking admin rights: {e}")
            # If we can't check admin rights, assume user is not an admin
            return False

