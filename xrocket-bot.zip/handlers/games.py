from aiogram import Dispatcher, F
from aiogram.types import Message, CallbackQuery, Dice
from aiogram.filters import Command
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
import random
from config.config import load_config

class GameStates(StatesGroup):
  choosing_game = State()
  configuring_emoji = State()
  configuring_wheel = State()
  configuring_bank = State()
  configuring_pvp = State()
  entering_bank_amount = State()
  entering_pvp_username = State()
  entering_pvp_amount = State()

async def cmd_games(message: Message, state: FSMContext):
  """Handle /games command"""
  kb = InlineKeyboardBuilder()
  kb.button(text="Emoji Game", callback_data="game_emoji")
  kb.button(text="Wheel of Fortune", callback_data="game_wheel")
  kb.button(text="Bank Game", callback_data="game_bank")
  kb.button(text="PvP Game", callback_data="game_pvp")
  kb.adjust(1)

  await message.answer(
      "🎮 <b>Games Menu</b>\n\n"
      "Choose a game to play:",
      reply_markup=kb.as_markup()
  )
  await state.set_state(GameStates.choosing_game)

async def game_emoji(callback: CallbackQuery, state: FSMContext):
  """Handle emoji game selection"""
  kb = InlineKeyboardBuilder()
  kb.button(text="🎰 Slot Machine", callback_data="emoji_slot")
  kb.button(text="🎲 Dice", callback_data="emoji_dice")
  kb.button(text="🏀 Basketball", callback_data="emoji_basketball")
  kb.button(text="⚽ Football", callback_data="emoji_football")
  kb.button(text="🎳 Bowling", callback_data="emoji_bowling")
  kb.button(text="🎯 Darts", callback_data="emoji_darts")
  kb.button(text="Back", callback_data="game_back")
  kb.adjust(2, 2, 2, 1)

  await callback.message.edit_text(
      "🎮 <b>Emoji Game</b>\n\n"
      "Choose an emoji type:",
      reply_markup=kb.as_markup()
  )
  await state.set_state(GameStates.configuring_emoji)
  await callback.answer()

async def emoji_selected(callback: CallbackQuery, state: FSMContext):
  """Handle emoji type selection"""
  emoji_type = callback.data.split("_")[1]
  emoji_map = {
      "slot": "🎰",
      "dice": "🎲",
      "basketball": "🏀",
      "football": "⚽",
      "bowling": "🎳",
      "darts": "🎯"
  }
  emoji = emoji_map.get(emoji_type, "🎮")

  await state.update_data(emoji_type=emoji_type, emoji=emoji)

  kb = InlineKeyboardBuilder()
  kb.button(text="Start Game", callback_data="emoji_start")
  kb.button(text="Configure Settings", callback_data="emoji_settings")
  kb.button(text="Back", callback_data="game_emoji")
  kb.adjust(1)

  await callback.message.edit_text(
      f"{emoji} <b>Emoji Game: {emoji_type.title()}</b>\n\n"
      f"Ready to start the game with {emoji}?\n\n"
      f"Default settings:\n"
      f"- Prize: 1.0 TON\n"
      f"- Infinite mode: Off\n"
      f"- Semi-wins: Off\n"
      f"- Attempts limit: 3",
      reply_markup=kb.as_markup()
  )
  await callback.answer()

async def emoji_settings(callback: CallbackQuery, state: FSMContext):
  """Configure emoji game settings"""
  state_data = await state.get_data()
  emoji = state_data.get("emoji", "🎮")

  kb = InlineKeyboardBuilder()
  kb.button(text="Set Prize Amount", callback_data="emoji_set_prize")
  kb.button(text="Toggle Infinite Mode", callback_data="emoji_toggle_infinite")
  kb.button(text="Toggle Semi-Wins", callback_data="emoji_toggle_semi_wins")
  kb.button(text="Set Attempts Limit", callback_data="emoji_set_attempts")
  kb.button(text="Back", callback_data="emoji_back")
  kb.adjust(1)

  await callback.message.edit_text(
      f"{emoji} <b>Emoji Game Settings</b>\n\n"
      f"Configure the game settings:",
      reply_markup=kb.as_markup()
  )
  await callback.answer()

async def emoji_start(callback: CallbackQuery, state: FSMContext):
  """Start emoji game"""
  # Check if webhooks are required but disabled
  config = load_config()
  state_data = await state.get_data()
  emoji = state_data.get("emoji", "🎮")
  emoji_type = state_data.get("emoji_type", "slot")
  prize_amount = state_data.get("prize_amount", 1.0)

  if not config.xrocket.use_webhooks and prize_amount > 0:
      await callback.message.edit_text(
          f"⚠️ <b>Webhooks Disabled</b>\n\n"
          f"Games with prizes require webhooks to process payments.\n"
          f"Please check your webhook settings or set prize amount to 0.",
      )
      await callback.answer()
      return

  kb = InlineKeyboardBuilder()
  kb.button(text="Join Game", callback_data="emoji_join")
  kb.button(text="Stop Game", callback_data="emoji_stop")
  kb.adjust(1)

  await callback.message.edit_text(
      f"{emoji} <b>Emoji Game Starting!</b>\n\n"
      f"The game will start in 2 minutes.\n\n"
      f"Game type: {emoji_type.title()} {emoji}\n"
      f"Prize: {prize_amount} TON\n\n"
      f"Click 'Join Game' to participate!",
      reply_markup=kb.as_markup()
  )
  await state.clear()
  await callback.answer()

async def game_wheel(callback: CallbackQuery, state: FSMContext):
  """Handle wheel of fortune selection"""
  kb = InlineKeyboardBuilder()
  kb.button(text="Start Game", callback_data="wheel_start")
  kb.button(text="Configure Settings", callback_data="wheel_settings")
  kb.button(text="Back", callback_data="game_back")
  kb.adjust(1)

  await callback.message.edit_text(
      "🎡 <b>Wheel of Fortune</b>\n\n"
      "Spin the wheel and win prizes!\n\n"
      "Default settings:\n"
      "- Prize: 1.0 TON\n"
      "- Tickets: 1 per user",
      reply_markup=kb.as_markup()
  )
  await state.set_state(GameStates.configuring_wheel)
  await callback.answer()

async def wheel_start(callback: CallbackQuery, state: FSMContext):
  """Start wheel of fortune game"""
  # Check if webhooks are required but disabled
  config = load_config()
  state_data = await state.get_data()
  prize_amount = state_data.get("prize_amount", 1.0)

  if not config.xrocket.use_webhooks and prize_amount > 0:
      await callback.message.edit_text(
          f"⚠️ <b>Webhooks Disabled</b>\n\n"
          f"Games with prizes require webhooks to process payments.\n"
          f"Please check your webhook settings or set prize amount to 0.",
      )
      await callback.answer()
      return
      
  kb = InlineKeyboardBuilder()
  kb.button(text="Join Game", callback_data="wheel_join")
  kb.button(text="Stop Game", callback_data="wheel_stop")
  kb.adjust(1)

  await callback.message.edit_text(
      "🎡 <b>Wheel of Fortune Starting!</b>\n\n"
      "The game will start in 2 minutes.\n\n"
      f"Prize: {prize_amount} TON\n\n"
      "Click 'Join Game' to participate!",
      reply_markup=kb.as_markup()
  )
  await state.clear()
  await callback.answer()

async def game_bank(callback: CallbackQuery, state: FSMContext):
  """Handle bank game selection"""
  kb = InlineKeyboardBuilder()
  kb.button(text="🎰 Slot Machine", callback_data="bank_slot")
  kb.button(text="🎲 Dice", callback_data="bank_dice")
  kb.button(text="🏀 Basketball", callback_data="bank_basketball")
  kb.button(text="⚽ Football", callback_data="bank_football")
  kb.button(text="🎳 Bowling", callback_data="bank_bowling")
  kb.button(text="🎯 Darts", callback_data="bank_darts")
  kb.button(text="No Emoji (Split)", callback_data="bank_none")
  kb.button(text="Back", callback_data="game_back")
  kb.adjust(2, 2, 2, 1, 1)

  await callback.message.edit_text(
      "💰 <b>Bank Game</b>\n\n"
      "Choose an emoji type or 'No Emoji' to split the bank equally:",
      reply_markup=kb.as_markup()
  )
  await state.set_state(GameStates.configuring_bank)
  await callback.answer()

async def bank_selected(callback: CallbackQuery, state: FSMContext):
  """Handle bank game emoji selection"""
  bank_type = callback.data.split("_")[1]
  emoji_map = {
      "slot": "🎰",
      "dice": "🎲",
      "basketball": "🏀",
      "football": "⚽",
      "bowling": "🎳",
      "darts": "🎯",
      "none": "💰"
  }
  emoji = emoji_map.get(bank_type, "💰")

  await state.update_data(bank_type=bank_type, emoji=emoji)

  kb = InlineKeyboardBuilder()
  kb.button(text="Cancel", callback_data="game_bank")

  await callback.message.edit_text(
      f"{emoji} <b>Bank Game: {bank_type.title() if bank_type != 'none' else 'Split'}</b>\n\n"
      f"Enter the amount for each participant (minimum 0.1 TON):",
      reply_markup=kb.as_markup()
  )
  await state.set_state(GameStates.entering_bank_amount)
  await callback.answer()

async def process_bank_amount(message: Message, state: FSMContext):
  """Process bank amount"""
  try:
      amount = float(message.text)
      if amount < 0.1:
          await message.answer(
              "⚠️ Amount must be at least 0.1 TON. Please enter a valid amount."
          )
          return
  except ValueError:
      await message.answer(
          "⚠️ Please enter a valid number."
      )
      return

  state_data = await state.get_data()
  bank_type = state_data.get("bank_type")
  emoji = state_data.get("emoji", "💰")

  await state.update_data(amount=amount)

  kb = InlineKeyboardBuilder()
  kb.button(text="TON", callback_data="bank_currency_TON")
  kb.button(text="USDT", callback_data="bank_currency_USDT")
  kb.button(text="Cancel", callback_data="game_bank")
  kb.adjust(2, 1)

  await message.answer(
      f"{emoji} <b>Bank Game: {bank_type.title() if bank_type != 'none' else 'Split'}</b>\n\n"
      f"Amount: {amount}\n\n"
      f"Choose currency:",
      reply_markup=kb.as_markup()
  )

async def bank_currency_selected(callback: CallbackQuery, state: FSMContext):
  """Handle bank currency selection"""
  currency = callback.data.split("_")[-1]
  state_data = await state.get_data()
  bank_type = state_data.get("bank_type")
  emoji = state_data.get("emoji", "💰")
  amount = state_data.get("amount", 0.1)

  await state.update_data(currency=currency)

  kb = InlineKeyboardBuilder()
  kb.button(text="Start Game", callback_data="bank_start")
  kb.button(text="Cancel", callback_data="game_bank")
  kb.adjust(1)

  await callback.message.edit_text(
      f"{emoji} <b>Bank Game: {bank_type.title() if bank_type != 'none' else 'Split'}</b>\n\n"
      f"Amount per participant: {amount} {currency}\n\n"
      f"Ready to start the game?",
      reply_markup=kb.as_markup()
  )
  await callback.answer()

async def bank_start(callback: CallbackQuery, state: FSMContext):
  """Start bank game"""
  # Check if webhooks are required but disabled
  config = load_config()
  if not config.xrocket.use_webhooks:
      await callback.message.edit_text(
          f"⚠️ <b>Webhooks Disabled</b>\n\n"
          f"Bank games require webhooks to process payments.\n"
          f"Please check your webhook settings.",
      )
      await callback.answer()
      return
      
  state_data = await state.get_data()
  bank_type = state_data.get("bank_type")
  emoji = state_data.get("emoji", "💰")
  amount = state_data.get("amount", 0.1)
  currency = state_data.get("currency", "TON")

  kb = InlineKeyboardBuilder()
  kb.button(text="Join Game", callback_data="bank_join")
  kb.button(text="Stop Game", callback_data="bank_stop")
  kb.adjust(1)

  game_type = "Split the bank equally" if bank_type == "none" else f"{bank_type.title()} {emoji} game"

  await callback.message.edit_text(
      f"{emoji} <b>Bank Game Starting!</b>\n\n"
      f"The game will start in 2 minutes.\n\n"
      f"Game type: {game_type}\n"
      f"Amount per participant: {amount} {currency}\n"
      f"Collection time: 5 minutes\n\n"
      f"Click 'Join Game' to participate!",
      reply_markup=kb.as_markup()
  )
  await state.clear()
  await callback.answer()

async def game_pvp(callback: CallbackQuery, state: FSMContext):
  """Handle PvP game selection"""
  kb = InlineKeyboardBuilder()
  kb.button(text="Cancel", callback_data="game_back")

  await callback.message.edit_text(
      "⚔️ <b>PvP Game</b>\n\n"
      "Enter the username of your opponent (with @):",
      reply_markup=kb.as_markup()
  )
  await state.set_state(GameStates.entering_pvp_username)
  await callback.answer()

async def process_pvp_username(message: Message, state: FSMContext):
  """Process PvP opponent username"""
  username = message.text

  if not username.startswith("@"):
      await message.answer(
          "⚠️ Please enter a valid username starting with @."
      )
      return

  await state.update_data(opponent_username=username)

  kb = InlineKeyboardBuilder()
  kb.button(text="Cancel", callback_data="game_pvp")

  await message.answer(
      f"⚔️ <b>PvP Game</b>\n\n"
      f"Opponent: {username}\n\n"
      f"Enter the stake amount (minimum 0.1 TON):",
      reply_markup=kb.as_markup()
  )
  await state.set_state(GameStates.entering_pvp_amount)

async def process_pvp_amount(message: Message, state: FSMContext):
  """Process PvP stake amount"""
  try:
      amount = float(message.text)
      if amount < 0.1:
          await message.answer(
              "⚠️ Amount must be at least 0.1 TON. Please enter a valid amount."
          )
          return
  except ValueError:
      await message.answer(
          "⚠️ Please enter a valid number."
      )
      return

  state_data = await state.get_data()
  opponent_username = state_data.get("opponent_username")

  await state.update_data(amount=amount)

  kb = InlineKeyboardBuilder()
  kb.button(text="TON", callback_data="pvp_currency_TON")
  kb.button(text="USDT", callback_data="pvp_currency_USDT")
  kb.button(text="Cancel", callback_data="game_pvp")
  kb.adjust(2, 1)

  await message.answer(
      f"⚔️ <b>PvP Game</b>\n\n"
      f"Opponent: {opponent_username}\n"
      f"Stake: {amount}\n\n"
      f"Choose currency:",
      reply_markup=kb.as_markup()
  )

async def pvp_currency_selected(callback: CallbackQuery, state: FSMContext):
  """Handle PvP currency selection"""
  currency = callback.data.split("_")[-1]
  state_data = await state.get_data()
  opponent_username = state_data.get("opponent_username")
  amount = state_data.get("amount", 0.1)

  await state.update_data(currency=currency)

  kb = InlineKeyboardBuilder()
  kb.button(text="Start Challenge", callback_data="pvp_start")
  kb.button(text="Cancel", callback_data="game_pvp")
  kb.adjust(1)

  await callback.message.edit_text(
      f"⚔️ <b>PvP Game</b>\n\n"
      f"Opponent: {opponent_username}\n"
      f"Stake: {amount} {currency}\n\n"
      f"Ready to challenge your opponent?",
      reply_markup=kb.as_markup()
  )
  await callback.answer()

async def pvp_start(callback: CallbackQuery, state: FSMContext):
  """Start PvP challenge"""
  # Check if webhooks are required but disabled
  config = load_config()
  if not config.xrocket.use_webhooks:
      await callback.message.edit_text(
          f"⚠️ <b>Webhooks Disabled</b>\n\n"
          f"PvP games require webhooks to process payments.\n"
          f"Please check your webhook settings.",
      )
      await callback.answer()
      return
      
  state_data = await state.get_data()
  opponent_username = state_data.get("opponent_username")
  amount = state_data.get("amount", 0.1)
  currency = state_data.get("currency", "TON")

  # Get PvP game service
  from games.pvp_game import PvpGame
  from services.payments import PaymentService
  from services.xrocket_api import XRocketAPI
  
  # This would typically be injected via dependency injection
  session = callback.bot.get("db_session")
  xrocket_api = XRocketAPI(config.xrocket.api_key, config.xrocket.api_url)
  payment_service = PaymentService(session, xrocket_api)
  pvp_game = PvpGame(session, payment_service)
  
  # Create challenge
  success, message, game_id = await pvp_game.create_challenge(
      challenger_id=callback.from_user.id,
      opponent_username=opponent_username.lstrip('@'),
      stake=amount,
      currency=currency,
      group_id=callback.message.chat.id
  )
  
  if not success:
      await callback.message.edit_text(
          f"⚠️ <b>Error</b>\n\n"
          f"{message}",
      )
      await callback.answer()
      return

  kb = InlineKeyboardBuilder()
  kb.button(text="Accept Challenge", callback_data=f"pvp_accept_{game_id}")
  kb.button(text="Decline Challenge", callback_data=f"pvp_decline_{game_id}")
  kb.adjust(1)

  await callback.message.edit_text(
      f"⚔️ <b>PvP Challenge!</b>\n\n"
      f"{callback.from_user.mention_html()} has challenged {opponent_username}!\n\n"
      f"Game: 🎲 Dice (3 attempts)\n"
      f"Stake: {amount/2} {currency} from each player\n"
      f"Total prize: {amount} {currency}\n\n"
      f"{opponent_username}, do you accept the challenge?",
      reply_markup=kb.as_markup()
  )
  await state.clear()
  await callback.answer()

async def pvp_accept(callback: CallbackQuery):
  """Accept PvP challenge"""
  game_id = callback.data.split("_")[-1]
  
  # Get PvP game service
  config = load_config()
  from games.pvp_game import PvpGame
  from services.payments import PaymentService
  from services.xrocket_api import XRocketAPI
  
  # This would typically be injected via dependency injection
  session = callback.bot.get("db_session")
  xrocket_api = XRocketAPI(config.xrocket.api_key, config.xrocket.api_url)
  payment_service = PaymentService(session, xrocket_api)
  pvp_game = PvpGame(session, payment_service)
  
  # Accept challenge
  success, message = await pvp_game.accept_challenge(
      game_id=game_id,
      opponent_id=callback.from_user.id
  )
  
  if not success:
      await callback.message.edit_text(
          f"⚠️ <b>Error</b>\n\n"
          f"{message}",
      )
      await callback.answer()
      return
  
  await callback.message.edit_text(
      f"⚔️ <b>Challenge Accepted!</b>\n\n"
      f"{message}\n\n"
      f"The game will start once both payments are confirmed.",
  )
  await callback.answer()

async def pvp_decline(callback: CallbackQuery):
  """Decline PvP challenge"""
  game_id = callback.data.split("_")[-1]
  
  # Get PvP game service
  config = load_config()
  from games.pvp_game import PvpGame
  from services.payments import PaymentService
  from services.xrocket_api import XRocketAPI
  
  # This would typically be injected via dependency injection
  session = callback.bot.get("db_session")
  xrocket_api = XRocketAPI(config.xrocket.api_key, config.xrocket.api_url)
  payment_service = PaymentService(session, xrocket_api)
  pvp_game = PvpGame(session, payment_service)
  
  # Cancel game
  success, message = await pvp_game.cancel_game(game_id=game_id)
  
  await callback.message.edit_text(
      f"⚔️ <b>Challenge Declined</b>\n\n"
      f"The challenge has been declined and the game cancelled.",
  )
  await callback.answer()

async def process_dice(message: Message):
  """Process dice in PvP game"""
  if not isinstance(message.dice, Dice) or message.dice.emoji != "🎲":
      return
  
  # Get PvP game service
  config = load_config()
  from games.pvp_game import PvpGame
  from services.payments import PaymentService
  from services.xrocket_api import XRocketAPI
  
  # This would typically be injected via dependency injection
  session = message.bot.get("db_session")
  xrocket_api = XRocketAPI(config.xrocket.api_key, config.xrocket.api_url)
  payment_service = PaymentService(session, xrocket_api)
  pvp_game = PvpGame(session, payment_service)
  
  # Find active PvP game for this user
  from sqlalchemy.future import select
  from database.models import PvpSession, Game
  
  result = await session.execute(
      select(PvpSession).join(Game).where(
          (PvpSession.challenger_id == message.from_user.id) | 
          (PvpSession.opponent_id == message.from_user.id),
          Game.status == "active"
      )
  )
  pvp_session = result.scalar_one_or_none()
  
  if not pvp_session:
      return
  
  # Process dice
  success, message_text, game_state = await pvp_game.process_dice(
      game_id=str(pvp_session.game_id),
      user_id=message.from_user.id,
      value=message.dice.value
  )
  
  if not success:
      await message.reply(message_text)
      return
  
  # If game is complete, announce the result
  if game_state.get("complete", False):
      challenger = game_state.get("challenger", {})
      opponent = game_state.get("opponent", {})
      result = game_state.get("result")
      
      result_text = ""
      if result == "challenger_win":
          result_text = f"@{challenger.get('username')} wins!"
      elif result == "opponent_win":
          result_text = f"@{opponent.get('username')} wins!"
      else:  # draw
          result_text = "It's a draw!"
      
      await message.reply(
          f"🎲 <b>PvP Game Completed!</b>\n\n"
          f"@{challenger.get('username')}: {challenger.get('score')} points\n"
          f"@{opponent.get('username')}: {opponent.get('score')} points\n\n"
          f"{result_text}"
      )

async def game_back(callback: CallbackQuery, state: FSMContext):
  """Handle back button in games menu"""
  await cmd_games(callback.message, state)
  await callback.answer()

def register_game_handlers(dp: Dispatcher):
  """Register game handlers"""
  dp.message.register(cmd_games, Command("games"))

  # Game selection
  dp.callback_query.register(game_emoji, F.data == "game_emoji")
  dp.callback_query.register(game_wheel, F.data == "game_wheel")
  dp.callback_query.register(game_bank, F.data == "game_bank")
  dp.callback_query.register(game_pvp, F.data == "game_pvp")
  dp.callback_query.register(game_back, F.data == "game_back")

  # Emoji game
  dp.callback_query.register(emoji_selected, F.data.startswith("emoji_") & ~F.data.in_(["emoji_start", "emoji_settings", "emoji_back"]))
  dp.callback_query.register(emoji_settings, F.data == "emoji_settings")
  dp.callback_query.register(emoji_start, F.data == "emoji_start")

  # Wheel game
  dp.callback_query.register(wheel_start, F.data == "wheel_start")

  # Bank game
  dp.callback_query.register(bank_selected, F.data.startswith("bank_") & ~F.data.in_(["bank_start", "bank_stop", "bank_join"]))
  dp.callback_query.register(bank_currency_selected, F.data.startswith("bank_currency_"))
  dp.callback_query.register(bank_start, F.data == "bank_start")
  dp.message.register(process_bank_amount, GameStates.entering_bank_amount)

  # PvP game
  dp.message.register(process_pvp_username, GameStates.entering_pvp_username)
  dp.message.register(process_pvp_amount, GameStates.entering_pvp_amount)
  dp.callback_query.register(pvp_currency_selected, F.data.startswith("pvp_currency_"))
  dp.callback_query.register(pvp_start, F.data == "pvp_start")
  dp.callback_query.register(pvp_accept, F.data.startswith("pvp_accept_"))
  dp.callback_query.register(pvp_decline, F.data.startswith("pvp_decline_"))
  dp.message.register(process_dice, F.dice)

