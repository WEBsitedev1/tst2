from aiogram import Dispatcher, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.utils.keyboard import InlineKeyboardBuilder

async def cmd_profile(message: Message):
    """Handle /profile command"""
    # This would typically fetch user data from the database
    await message.answer(
        "👤 <b>Your Profile</b>\n\n"
        "Here you can see your profile information and statistics.\n\n"
        "Use the buttons below to manage your profile."
    )

def register_user_handlers(dp: Dispatcher):
    """Register user handlers"""
    dp.message.register(cmd_profile, Command("profile"))

