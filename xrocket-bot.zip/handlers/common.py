from aiogram import Dispatcher, F
from aiogram.types import Message
from aiogram.filters import Command

async def cmd_start(message: Message):
    """Handle /start command"""
    await message.answer(
        "👋 Welcome to the xRocket Bot!\n\n"
        "This bot allows you to play games, set statuses, and connect your TON wallet.\n\n"
        "Use the menu below to get started."
    )

async def cmd_help(message: Message):
    """Handle /help command"""
    await message.answer(
        "📚 <b>Bot Help</b>\n\n"
        "<b>User Commands:</b>\n"
        "/start - Start the bot\n"
        "/help - Show this help message\n"
        "/wallet - Connect or manage your wallet\n"
        "/status - Set or view your status\n\n"
        
        "<b>Admin Commands (in groups):</b>\n"
        "/games - Manage games in the group\n"
        "/settings - Configure group settings\n"
        "/admin - Manage group admins\n\n"
        
        "For more information, contact @f_row"
    )

def register_common_handlers(dp: Dispatcher):
    """Register common handlers"""
    dp.message.register(cmd_start, Command("start"))
    dp.message.register(cmd_help, Command("help"))

