from aiogram import Dispatcher, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from config.config import load_config

class StatusStates(StatesGroup):
  choosing_type = State()
  entering_text_self = State()
  entering_username = State()
  entering_text_other = State()
  confirming = State()

async def cmd_status(message: Message, state: FSMContext):
  """Handle /status command"""
  # Check if webhooks are enabled
  config = load_config()
  if not config.xrocket.use_webhooks:
      await message.answer(
          "⚠️ <b>Webhooks Disabled</b>\n\n"
          "Status setting requires webhooks to process payments.\n"
          "Please check your webhook settings."
      )
      return
      
  kb = InlineKeyboardBuilder()
  kb.button(text="Set Status for Yourself", callback_data="status_self")
  kb.button(text="Set Status for Someone Else", callback_data="status_other")
  kb.button(text="View Current Status", callback_data="status_view")
  kb.adjust(1)
  
  await message.answer(
      "🏷️ <b>Status Management</b>\n\n"
      "Set a custom status for yourself or someone else.\n\n"
      "Choose an option below:",
      reply_markup=kb.as_markup()
  )

async def status_self(callback: CallbackQuery, state: FSMContext):
  """Handle status_self callback"""
  # This would typically fetch the price from global_settings
  price = 1.0
  currency = "TON"
  
  await state.update_data(type="self", price=price, currency=currency)
  
  kb = InlineKeyboardBuilder()
  kb.button(text="Cancel", callback_data="status_cancel")
  
  await callback.message.edit_text(
      f"✍️ <b>Set Status for Yourself</b>\n\n"
      f"Price: {price} {currency}\n\n"
      f"Enter the text for your status (max 50 characters):",
      reply_markup=kb.as_markup()
  )
  await state.set_state(StatusStates.entering_text_self)
  await callback.answer()

async def process_status_text_self(message: Message, state: FSMContext):
  """Process status text for self"""
  status_text = message.text
  
  if len(status_text) > 50:
      await message.answer(
          "⚠️ Status text is too long. Please enter a text with maximum 50 characters."
      )
      return
  
  state_data = await state.get_data()
  price = state_data.get("price", 1.0)
  currency = state_data.get("currency", "TON")
  
  await state.update_data(status_text=status_text)
  
  kb = InlineKeyboardBuilder()
  kb.button(text="Confirm", callback_data="status_confirm")
  kb.button(text="Cancel", callback_data="status_cancel")
  kb.adjust(1)
  
  await message.answer(
      f"🔍 <b>Confirm Status</b>\n\n"
      f"Status Text: <i>{status_text}</i>\n"
      f"Price: {price} {currency}\n\n"
      f"Do you want to proceed with this status?",
      reply_markup=kb.as_markup()
  )
  await state.set_state(StatusStates.confirming)

async def status_other(callback: CallbackQuery, state: FSMContext):
  """Handle status_other callback"""
  # This would typically fetch the price from global_settings
  price = 2.0
  currency = "TON"
  
  await state.update_data(type="other", price=price, currency=currency)
  
  kb = InlineKeyboardBuilder()
  kb.button(text="Cancel", callback_data="status_cancel")
  
  await callback.message.edit_text(
      f"👤 <b>Set Status for Someone Else</b>\n\n"
      f"Price: {price} {currency}\n\n"
      f"Enter the username of the person (with @):",
      reply_markup=kb.as_markup()
  )
  await state.set_state(StatusStates.entering_username)
  await callback.answer()

async def process_username(message: Message, state: FSMContext):
  """Process username for status_other"""
  username = message.text
  
  if not username.startswith("@"):
      await message.answer(
          "⚠️ Please enter a valid username starting with @."
      )
      return
  
  await state.update_data(target_username=username)
  
  kb = InlineKeyboardBuilder()
  kb.button(text="Cancel", callback_data="status_cancel")
  
  await message.answer(
      f"✍️ <b>Set Status for {username}</b>\n\n"
      f"Now enter the text for the status (max 50 characters):",
      reply_markup=kb.as_markup()
  )
  await state.set_state(StatusStates.entering_text_other)

async def process_status_text_other(message: Message, state: FSMContext):
  """Process status text for other"""
  status_text = message.text
  
  if len(status_text) > 50:
      await message.answer(
          "⚠️ Status text is too long. Please enter a text with maximum 50 characters."
      )
      return
  
  state_data = await state.get_data()
  target_username = state_data.get("target_username")
  price = state_data.get("price", 2.0)
  currency = state_data.get("currency", "TON")
  
  await state.update_data(status_text=status_text)
  
  kb = InlineKeyboardBuilder()
  kb.button(text="Confirm", callback_data="status_confirm")
  kb.button(text="Cancel", callback_data="status_cancel")
  kb.adjust(1)
  
  await message.answer(
      f"🔍 <b>Confirm Status</b>\n\n"
      f"Target User: {target_username}\n"
      f"Status Text: <i>{status_text}</i>\n"
      f"Price: {price} {currency}\n\n"
      f"Do you want to proceed with this status?",
      reply_markup=kb.as_markup()
  )
  await state.set_state(StatusStates.confirming)

async def status_confirm(callback: CallbackQuery, state: FSMContext):
  """Confirm status purchase"""
  state_data = await state.get_data()
  status_type = state_data.get("type")
  status_text = state_data.get("status_text")
  price = state_data.get("price")
  currency = state_data.get("currency")
  
  # This would typically create an invoice via xRocket
  # For demo purposes, we'll simulate a successful payment
  
  kb = InlineKeyboardBuilder()
  kb.button(text="Done", callback_data="status_done")
  
  if status_type == "self":
      await callback.message.edit_text(
          f"✅ <b>Status Purchased!</b>\n\n"
          f"Your new status: <i>{status_text}</i>\n\n"
          f"Your status has been set successfully.",
          reply_markup=kb.as_markup()
      )
  else:
      target_username = state_data.get("target_username")
      await callback.message.edit_text(
          f"✅ <b>Status Purchased!</b>\n\n"
          f"Status for {target_username}: <i>{status_text}</i>\n\n"
          f"The status has been set successfully.",
          reply_markup=kb.as_markup()
      )
  
  await state.clear()
  await callback.answer()

async def status_view(callback: CallbackQuery):
  """View current status"""
  # This would typically fetch the status from the database
  kb = InlineKeyboardBuilder()
  kb.button(text="Back", callback_data="status_back")
  
  await callback.message.edit_text(
      "🏷️ <b>Your Current Status</b>\n\n"
      "Status: <i>VIP Member</i>\n"
      "Set on: 2023-06-15 14:30:45",
      reply_markup=kb.as_markup()
  )
  await callback.answer()

async def status_cancel(callback: CallbackQuery, state: FSMContext):
  """Handle cancel button"""
  await state.clear()
  await cmd_status(callback.message, state)
  await callback.answer("Operation cancelled")

async def status_back(callback: CallbackQuery, state: FSMContext):
  """Handle back button"""
  await state.clear()
  await cmd_status(callback.message, state)
  await callback.answer()

async def status_done(callback: CallbackQuery, state: FSMContext):
  """Handle done button"""
  await state.clear()
  await cmd_status(callback.message, state)
  await callback.answer()

def register_status_handlers(dp: Dispatcher):
  """Register status handlers"""
  dp.message.register(cmd_status, Command("status"))
  dp.callback_query.register(status_self, F.data == "status_self")
  dp.callback_query.register(status_other, F.data == "status_other")
  dp.callback_query.register(status_view, F.data == "status_view")
  dp.callback_query.register(status_confirm, F.data == "status_confirm")
  dp.callback_query.register(status_cancel, F.data == "status_cancel")
  dp.callback_query.register(status_back, F.data == "status_back")
  dp.callback_query.register(status_done, F.data == "status_done")
  dp.message.register(process_status_text_self, StatusStates.entering_text_self)
  dp.message.register(process_username, StatusStates.entering_username)
  dp.message.register(process_status_text_other, StatusStates.entering_text_other)

