from aiogram import Dispatcher, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from config.config import load_config

class DevStates(StatesGroup):
  entering_ad_text = State()
  entering_commission = State()
  entering_currency = State()
  entering_status_self_price = State()
  entering_status_other_price = State()
  entering_bank_min_amount = State()
  entering_pvp_min_stake = State()
  entering_status_char_limit = State()
  entering_game_start_delay = State()
  entering_bank_collection_time = State()
  entering_pvp_payment_timeout = State()

async def cmd_dev(message: Message, state: FSMContext):
  """Handle /dev command"""
  # Check if the user is a developer
  config = load_config()
  if message.from_user.id not in config.tg_bot.dev_ids:
      await message.answer("⚠️ У вас нет прав для использования этой команды.")
      return
  
  kb = InlineKeyboardBuilder()
  kb.button(text="Disable Bot", callback_data="dev_disable")
  kb.button(text="Enable Bot", callback_data="dev_enable")
  kb.button(text="Advertisements", callback_data="dev_ads")
  kb.button(text="Groups", callback_data="dev_groups")
  kb.button(text="Settings", callback_data="dev_settings")
  kb.adjust(1)
  
  await message.answer(
      "🛠️ <b>Developer Panel</b>\n\n"
      "Welcome to the developer panel. Choose an option below:",
      reply_markup=kb.as_markup()
  )

async def dev_ads(callback: CallbackQuery, state: FSMContext):
  """Handle dev_ads callback"""
  # Check if the user is a developer
  config = load_config()
  if callback.from_user.id not in config.tg_bot.dev_ids:
      await callback.answer("У вас нет прав для использования этой функции.", show_alert=True)
      return
      
  # This would typically fetch groups from the database
  groups = [
      {"id": 1, "name": "Group 1"},
      {"id": 2, "name": "Group 2"},
      {"id": 3, "name": "Group 3"}
  ]
  
  kb = InlineKeyboardBuilder()
  for group in groups:
      kb.button(text=group["name"], callback_data=f"dev_ads_group_{group['id']}")
  
  kb.button(text="◄", callback_data="dev_ads_prev")
  kb.button(text="1", callback_data="dev_ads_page_1")
  kb.button(text="►", callback_data="dev_ads_next")
  kb.button(text="Back", callback_data="dev_back")
  kb.adjust(1, 3, 1)
  
  await callback.message.edit_text(
      "📢 <b>Advertisements</b>\n\n"
      "Select a group to manage advertisements:",
      reply_markup=kb.as_markup()
  )
  await callback.answer()

async def dev_ads_group(callback: CallbackQuery, state: FSMContext):
  """Handle dev_ads_group callback"""
  # Check if the user is a developer
  config = load_config()
  if callback.from_user.id not in config.tg_bot.dev_ids:
      await callback.answer("У вас нет прав для использования этой функции.", show_alert=True)
      return
      
  group_id = int(callback.data.split("_")[-1])
  await state.update_data(group_id=group_id)
  
  # This would typically fetch group info from the database
  group_name = f"Group {group_id}"
  
  kb = InlineKeyboardBuilder()
  kb.button(text="➕ Add Advertisement", callback_data="dev_ads_add")
  kb.button(text="➖ Remove Advertisement", callback_data="dev_ads_remove")
  kb.button(text="Enable Advertisement", callback_data="dev_ads_enable")
  kb.button(text="Disable Advertisement", callback_data="dev_ads_disable")
  kb.button(text="Disable Ads in Group", callback_data="dev_ads_disable_group")
  kb.button(text="Enable Ads in Group", callback_data="dev_ads_enable_group")
  kb.button(text="Back", callback_data="dev_ads")
  kb.adjust(1)
  
  await callback.message.edit_text(
      f"📢 <b>Advertisements for {group_name}</b>\n\n"
      f"Choose an action:",
      reply_markup=kb.as_markup()
  )
  await callback.answer()

async def dev_ads_add(callback: CallbackQuery, state: FSMContext):
  """Handle dev_ads_add callback"""
  # Check if the user is a developer
  config = load_config()
  if callback.from_user.id not in config.tg_bot.dev_ids:
      await callback.answer("У вас нет прав для использования этой функции.", show_alert=True)
      return
      
  state_data = await state.get_data()
  group_id = state_data.get("group_id")
  
  # This would typically fetch group info from the database
  group_name = f"Group {group_id}"
  
  kb = InlineKeyboardBuilder()
  kb.button(text="Cancel", callback_data="dev_ads_group_" + str(group_id))
  
  await callback.message.edit_text(
      f"📢 <b>Add Advertisement for {group_name}</b>\n\n"
      f"Enter the text for the advertisement:",
      reply_markup=kb.as_markup()
  )
  await state.set_state(DevStates.entering_ad_text)
  await callback.answer()

async def process_ad_text(message: Message, state: FSMContext):
  """Process advertisement text"""
  # Check if the user is a developer
  config = load_config()
  if message.from_user.id not in config.tg_bot.dev_ids:
      await message.answer("У вас нет прав для использования этой функции.")
      return
      
  ad_text = message.text
  state_data = await state.get_data()
  group_id = state_data.get("group_id")
  
  # This would typically add the advertisement to the database
  
  kb = InlineKeyboardBuilder()
  kb.button(text="Back to Group", callback_data="dev_ads_group_" + str(group_id))
  
  await message.answer(
      f"✅ <b>Advertisement Added</b>\n\n"
      f"The advertisement has been added successfully.",
      reply_markup=kb.as_markup()
  )
  await state.clear()

async def dev_groups(callback: CallbackQuery, state: FSMContext):
  """Handle dev_groups callback"""
  # Check if the user is a developer
  config = load_config()
  if callback.from_user.id not in config.tg_bot.dev_ids:
      await callback.answer("У вас нет прав для использования этой функции.", show_alert=True)
      return
      
  # This would typically fetch groups from the database
  groups = [
      {"id": 1, "name": "Group 1"},
      {"id": 2, "name": "Group 2"},
      {"id": 3, "name": "Group 3"}
  ]
  
  kb = InlineKeyboardBuilder()
  for group in groups:
      kb.button(text=group["name"], callback_data=f"dev_groups_group_{group['id']}")
  
  kb.button(text="◄", callback_data="dev_groups_prev")
  kb.button(text="1", callback_data="dev_groups_page_1")
  kb.button(text="►", callback_data="dev_groups_next")
  kb.button(text="Back", callback_data="dev_back")
  kb.adjust(1, 3, 1)
  
  await callback.message.edit_text(
      "👥 <b>Groups</b>\n\n"
      "Select a group to manage:",
      reply_markup=kb.as_markup()
  )
  await callback.answer()

async def dev_groups_group(callback: CallbackQuery, state: FSMContext):
  """Handle dev_groups_group callback"""
  # Check if the user is a developer
  config = load_config()
  if callback.from_user.id not in config.tg_bot.dev_ids:
      await callback.answer("У вас нет прав для использования этой функции.", show_alert=True)
      return
      
  group_id = int(callback.data.split("_")[-1])
  await state.update_data(group_id=group_id)
  
  # This would typically fetch group info from the database
  group_name = f"Group {group_id}"
  
  kb = InlineKeyboardBuilder()
  kb.button(text="Block Group", callback_data="dev_groups_block")
  kb.button(text="Unblock Group", callback_data="dev_groups_unblock")
  kb.button(text="Change Local Commission", callback_data="dev_groups_commission")
  kb.button(text="Set Local Currency", callback_data="dev_groups_currency")
  kb.button(text="Remove Local Currency", callback_data="dev_groups_remove_currency")
  kb.button(text="Back", callback_data="dev_groups")
  kb.adjust(1)
  
  await callback.message.edit_text(
      f"👥 <b>Group: {group_name}</b>\n\n"
      f"Choose an action:",
      reply_markup=kb.as_markup()
  )
  await callback.answer()

async def dev_settings(callback: CallbackQuery, state: FSMContext):
  """Handle dev_settings callback"""
  # Check if the user is a developer
  config = load_config()
  if callback.from_user.id not in config.tg_bot.dev_ids:
      await callback.answer("У вас нет прав для использования этой функции.", show_alert=True)
      return
      
  kb = InlineKeyboardBuilder()
  kb.button(text="Set Global Currency", callback_data="dev_settings_global_currency")
  kb.button(text="Add Currency", callback_data="dev_settings_add_currency")
  kb.button(text="Disable Currency", callback_data="dev_settings_disable_currency")
  kb.button(text="Enable Currency", callback_data="dev_settings_enable_currency")
  kb.button(text="Change Global Commission", callback_data="dev_settings_global_commission")
  kb.button(text="Change Status Self Commission", callback_data="dev_settings_status_self_commission")
  kb.button(text="Change Status Other Commission", callback_data="dev_settings_status_other_commission")
  kb.button(text="Change Status Self Price", callback_data="dev_settings_status_self_price")
  kb.button(text="Change Status Other Price", callback_data="dev_settings_status_other_price")
  kb.button(text="Change Bank Min Amount", callback_data="dev_settings_bank_min_amount")
  kb.button(text="Change PvP Min Stake", callback_data="dev_settings_pvp_min_stake")
  kb.button(text="Change Status Char Limit", callback_data="dev_settings_status_char_limit")
  kb.button(text="Change Game Start Delay", callback_data="dev_settings_game_start_delay")
  kb.button(text="Change Bank Collection Time", callback_data="dev_settings_bank_collection_time")
  kb.button(text="Change PvP Payment Timeout", callback_data="dev_settings_pvp_payment_timeout")
  kb.button(text="Show Current Settings", callback_data="dev_settings_show")
  kb.button(text="Show Current Exchange Rates", callback_data="dev_settings_rates")
  kb.button(text="Back", callback_data="dev_back")
  kb.adjust(1)
  
  await callback.message.edit_text(
      "⚙️ <b>Global Settings</b>\n\n"
      "Choose a setting to configure:",
      reply_markup=kb.as_markup()
  )
  await callback.answer()

async def dev_settings_show(callback: CallbackQuery):
  """Show current settings"""
  # Check if the user is a developer
  config = load_config()
  if callback.from_user.id not in config.tg_bot.dev_ids:
      await callback.answer("У вас нет прав для использования этой функции.", show_alert=True)
      return
      
  # This would typically fetch settings from the database
  settings = {
      "global_currency": "TON",
      "global_commission": "10%",
      "status_self_commission": "5%",
      "status_other_commission": "10%",
      "status_self_price": "1.0 TON",
      "status_other_price": "2.0 TON",
      "bank_min_amount": "0.1 TON",
      "pvp_min_stake": "0.1 TON",
      "status_char_limit": "50",
      "game_start_delay": "2 minutes",
      "bank_collection_time": "5 minutes",
      "pvp_payment_timeout": "5 minutes"
  }
  
  settings_text = "\n".join([f"{k}: {v}" for k, v in settings.items()])
  
  kb = InlineKeyboardBuilder()
  kb.button(text="Back", callback_data="dev_settings")
  
  await callback.message.edit_text(
      f"⚙️ <b>Current Settings</b>\n\n"
      f"{settings_text}",
      reply_markup=kb.as_markup()
  )
  await callback.answer()

async def dev_back(callback: CallbackQuery, state: FSMContext):
  """Handle dev_back callback"""
  # Check if the user is a developer
  config = load_config()
  if callback.from_user.id not in config.tg_bot.dev_ids:
      await callback.answer("У вас нет прав для использования этой функции.", show_alert=True)
      return
      
  await state.clear()
  await cmd_dev(callback.message, state)
  await callback.answer()

def register_dev_handlers(dp: Dispatcher):
  """Register developer handlers"""
  dp.message.register(cmd_dev, Command("dev"))
  dp.callback_query.register(dev_ads, F.data == "dev_ads")
  dp.callback_query.register(dev_ads_group, F.data.startswith("dev_ads_group_"))
  dp.callback_query.register(dev_ads_add, F.data == "dev_ads_add")
  dp.callback_query.register(dev_groups, F.data == "dev_groups")
  dp.callback_query.register(dev_groups_group, F.data.startswith("dev_groups_group_"))
  dp.callback_query.register(dev_settings, F.data == "dev_settings")
  dp.callback_query.register(dev_settings_show, F.data == "dev_settings_show")
  dp.callback_query.register(dev_back, F.data == "dev_back")
  dp.message.register(process_ad_text, DevStates.entering_ad_text)

