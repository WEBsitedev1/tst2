from aiogram import Dispatcher, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

class AdminStates(StatesGroup):
  entering_token = State()
  entering_ca = State()
  entering_min_tokens = State()
  entering_prize_amount = State()
  entering_custom_prize = State()
  entering_admin_username = State()
  entering_commission = State()

async def cmd_admin(message: Message):
  """Handle /admin command"""
  # This would typically check if the user is an admin of the current group
  is_admin = True  # This should be a real check in production
  
  if not is_admin:
      await message.answer("⚠️ You don't have permission to use this command.")
      return
  
  kb = InlineKeyboardBuilder()
  kb.button(text="Buy Advertisement", url="https://t.me/f_row")
  kb.button(text="Games", callback_data="admin_games")
  kb.button(text="Settings", callback_data="admin_settings")
  kb.button(text="Add Admin", callback_data="admin_add")
  kb.button(text="Remove Admin", callback_data="admin_remove")
  kb.adjust(1)
  
  await message.answer(
      "👑 <b>Admin Panel</b>\n\n"
      "Welcome to the admin panel. Choose an option below:",
      reply_markup=kb.as_markup()
  )

async def admin_games(callback: CallbackQuery):
  """Handle admin_games callback"""
  # This would typically check if the user is an admin of the current group
  is_admin = True  # This should be a real check in production
  
  if not is_admin:
      await callback.answer("You don't have permission to use this function.", show_alert=True)
      return
      
  kb = InlineKeyboardBuilder()
  kb.button(text="Emoji Game", callback_data="admin_emoji")
  kb.button(text="Wheel of Fortune", callback_data="admin_wheel")
  kb.button(text="Back", callback_data="admin_back")
  kb.adjust(1)
  
  await callback.message.edit_text(
      "🎮 <b>Games Management</b>\n\n"
      "Choose a game to manage:",
      reply_markup=kb.as_markup()
  )
  await callback.answer()

async def admin_emoji(callback: CallbackQuery):
  """Handle admin_emoji callback"""
  # This would typically check if the user is an admin of the current group
  is_admin = True  # This should be a real check in production
  
  if not is_admin:
      await callback.answer("You don't have permission to use this function.", show_alert=True)
      return
      
  kb = InlineKeyboardBuilder()
  kb.button(text="Start Game", callback_data="admin_emoji_start")
  kb.button(text="Stop Game", callback_data="admin_emoji_stop")
  kb.button(text="Change Emoji", callback_data="admin_emoji_change")
  kb.button(text="Infinite Mode", callback_data="admin_emoji_infinite")
  kb.button(text="Semi-Wins", callback_data="admin_emoji_semi_wins")
  kb.button(text="Attempts Limit", callback_data="admin_emoji_attempts")
  kb.button(text="Back", callback_data="admin_games")
  kb.adjust(1)
  
  await callback.message.edit_text(
      "🎮 <b>Emoji Game Management</b>\n\n"
      "Choose an option:",
      reply_markup=kb.as_markup()
  )
  await callback.answer()

async def admin_emoji_change(callback: CallbackQuery):
  """Handle admin_emoji_change callback"""
  # This would typically check if the user is an admin of the current group
  is_admin = True  # This should be a real check in production
  
  if not is_admin:
      await callback.answer("You don't have permission to use this function.", show_alert=True)
      return
      
  kb = InlineKeyboardBuilder()
  kb.button(text="🎰 Slot Machine", callback_data="admin_emoji_set_slot")
  kb.button(text="🎲 Dice", callback_data="admin_emoji_set_dice")
  kb.button(text="🏀 Basketball", callback_data="admin_emoji_set_basketball")
  kb.button(text="⚽ Football", callback_data="admin_emoji_set_football")
  kb.button(text="🎳 Bowling", callback_data="admin_emoji_set_bowling")
  kb.button(text="🎯 Darts", callback_data="admin_emoji_set_darts")
  kb.button(text="Back", callback_data="admin_emoji")
  kb.adjust(2, 2, 2, 1)
  
  await callback.message.edit_text(
      "🎮 <b>Change Emoji</b>\n\n"
      "Choose an emoji type:",
      reply_markup=kb.as_markup()
  )
  await callback.answer()

async def admin_settings(callback: CallbackQuery):
  """Handle admin_settings callback"""
  # This would typically check if the user is an admin of the current group
  is_admin = True  # This should be a real check in production
  
  if not is_admin:
      await callback.answer("You don't have permission to use this function.", show_alert=True)
      return
      
  kb = InlineKeyboardBuilder()
  kb.button(text="xRocket Pay", callback_data="admin_xrocket")
  kb.button(text="Current Settings", callback_data="admin_current_settings")
  kb.button(text="Holders Only", callback_data="admin_holders")
  kb.button(text="Prize", callback_data="admin_prize")
  kb.button(text="Tickets", callback_data="admin_tickets")
  kb.button(text="Back", callback_data="admin_back")
  kb.adjust(1)
  
  await callback.message.edit_text(
      "⚙️ <b>Settings</b>\n\n"
      "Choose a setting to configure:",
      reply_markup=kb.as_markup()
  )
  await callback.answer()

async def admin_xrocket(callback: CallbackQuery):
  """Handle admin_xrocket callback"""
  # This would typically check if the user is an admin of the current group
  is_admin = True  # This should be a real check in production
  
  if not is_admin:
      await callback.answer("You don't have permission to use this function.", show_alert=True)
      return
      
  kb = InlineKeyboardBuilder()
  kb.button(text="Set Token", callback_data="admin_xrocket_set")
  kb.button(text="Remove Token", callback_data="admin_xrocket_remove")
  kb.button(text="Back", callback_data="admin_settings")
  kb.adjust(1)
  
  await callback.message.edit_text(
      "💰 <b>xRocket Pay</b>\n\n"
      "Configure xRocket Pay integration:",
      reply_markup=kb.as_markup()
  )
  await callback.answer()

async def admin_holders(callback: CallbackQuery):
  """Handle admin_holders callback"""
  # This would typically check if the user is an admin of the current group
  is_admin = True  # This should be a real check in production
  
  if not is_admin:
      await callback.answer("You don't have permission to use this function.", show_alert=True)
      return
      
  kb = InlineKeyboardBuilder()
  kb.button(text="Set Contract Address", callback_data="admin_holders_ca")
  kb.button(text="Set Min Tokens", callback_data="admin_holders_min")
  kb.button(text="Enable", callback_data="admin_holders_enable")
  kb.button(text="Disable", callback_data="admin_holders_disable")
  kb.button(text="Back", callback_data="admin_settings")
  kb.adjust(1)
  
  await callback.message.edit_text(
      "👥 <b>Holders Only</b>\n\n"
      "Configure 'Holders Only' mode:",
      reply_markup=kb.as_markup()
  )
  await callback.answer()

async def admin_prize(callback: CallbackQuery):
  """Handle admin_prize callback"""
  # This would typically check if the user is an admin of the current group
  is_admin = True  # This should be a real check in production
  
  if not is_admin:
      await callback.answer("You don't have permission to use this function.", show_alert=True)
      return
      
  kb = InlineKeyboardBuilder()
  kb.button(text="Set Amount", callback_data="admin_prize_amount")
  kb.button(text="Custom Prize", callback_data="admin_prize_custom")
  kb.button(text="Prize Currency", callback_data="admin_prize_currency")
  kb.button(text="Back", callback_data="admin_settings")
  kb.adjust(1)
  
  await callback.message.edit_text(
      "🏆 <b>Prize Settings</b>\n\n"
      "Configure prize settings:",
      reply_markup=kb.as_markup()
  )
  await callback.answer()

async def admin_prize_custom(callback: CallbackQuery, state: FSMContext):
  """Handle admin_prize_custom callback"""
  # This would typically check if the user is an admin of the current group
  is_admin = True  # This should be a real check in production
  
  if not is_admin:
      await callback.answer("You don't have permission to use this function.", show_alert=True)
      return
      
  kb = InlineKeyboardBuilder()
  kb.button(text="Set Custom Prize", callback_data="admin_prize_custom_set")
  kb.button(text="Enable Custom Prize", callback_data="admin_prize_custom_enable")
  kb.button(text="Disable Custom Prize", callback_data="admin_prize_custom_disable")
  kb.button(text="Back", callback_data="admin_prize")
  kb.adjust(1)
  
  await callback.message.edit_text(
      "🎁 <b>Custom Prize</b>\n\n"
      "Configure custom prize instead of coins:",
      reply_markup=kb.as_markup()
  )
  await callback.answer()

async def admin_prize_currency(callback: CallbackQuery):
  """Handle admin_prize_currency callback"""
  # This would typically check if the user is an admin of the current group
  is_admin = True  # This should be a real check in production
  
  if not is_admin:
      await callback.answer("You don't have permission to use this function.", show_alert=True)
      return
      
  kb = InlineKeyboardBuilder()
  kb.button(text="TON", callback_data="admin_prize_currency_ton")
  kb.button(text="USDT", callback_data="admin_prize_currency_usdt")
  kb.button(text="Back", callback_data="admin_prize")
  kb.adjust(2, 1)
  
  await callback.message.edit_text(
      "💱 <b>Prize Currency</b>\n\n"
      "Choose the currency for prizes:",
      reply_markup=kb.as_markup()
  )
  await callback.answer()

async def admin_add(callback: CallbackQuery, state: FSMContext):
  """Handle admin_add callback"""
  # This would typically check if the user is an admin of the current group
  is_admin = True  # This should be a real check in production
  
  _admin = True  # This should be a real check in production
  
  if not is_admin:
      await callback.answer("You don't have permission to use this function.", show_alert=True)
      return
      
  kb = InlineKeyboardBuilder()
  kb.button(text="Cancel", callback_data="admin_back")
  
  await callback.message.edit_text(
      "➕ <b>Add Admin</b>\n\n"
      "Enter the username of the user you want to add as admin (with @):",
      reply_markup=kb.as_markup()
  )
  await state.set_state(AdminStates.entering_admin_username)
  await callback.answer()

async def process_admin_username(message: Message, state: FSMContext):
  """Process admin username"""
  # This would typically check if the user is an admin of the current group
  is_admin = True  # This should be a real check in production
  
  if not is_admin:
      await message.answer("You don't have permission to use this function.")
      return
      
  username = message.text
  
  if not username.startswith("@"):
      await message.answer(
          "⚠️ Please enter a valid username starting with @."
      )
      return
  
  # This would typically add the user as admin in the database
  
  kb = InlineKeyboardBuilder()
  kb.button(text="Back to Admin Panel", callback_data="admin_back")
  
  await message.answer(
      f"✅ <b>Admin Added</b>\n\n"
      f"User {username} has been added as an admin.",
      reply_markup=kb.as_markup()
  )
  await state.clear()

async def admin_remove(callback: CallbackQuery, state: FSMContext):
  """Handle admin_remove callback"""
  # This would typically check if the user is an admin of the current group
  is_admin = True  # This should be a real check in production
  
  if not is_admin:
      await callback.answer("You don't have permission to use this function.", show_alert=True)
      return
      
  # This would typically fetch the list of admins from the database
  admins = ["@user1", "@user2", "@user3"]
  
  kb = InlineKeyboardBuilder()
  for admin in admins:
      kb.button(text=f"Remove {admin}", callback_data=f"admin_remove_{admin}")
  kb.button(text="Back", callback_data="admin_back")
  kb.adjust(1)
  
  await callback.message.edit_text(
      "➖ <b>Remove Admin</b>\n\n"
      "Select an admin to remove:",
      reply_markup=kb.as_markup()
  )
  await callback.answer()

async def admin_back(callback: CallbackQuery, state: FSMContext):
  """Handle admin_back callback"""
  await state.clear()
  await cmd_admin(callback.message)
  await callback.answer()

def register_admin_handlers(dp: Dispatcher):
  """Register admin handlers"""
  dp.message.register(cmd_admin, Command("admin"))
  dp.callback_query.register(admin_games, F.data == "admin_games")
  dp.callback_query.register(admin_emoji, F.data == "admin_emoji")
  dp.callback_query.register(admin_emoji_change, F.data == "admin_emoji_change")
  dp.callback_query.register(admin_settings, F.data == "admin_settings")
  dp.callback_query.register(admin_xrocket, F.data == "admin_xrocket")
  dp.callback_query.register(admin_holders, F.data == "admin_holders")
  dp.callback_query.register(admin_prize, F.data == "admin_prize")
  dp.callback_query.register(admin_prize_custom, F.data == "admin_prize_custom")
  dp.callback_query.register(admin_prize_currency, F.data == "admin_prize_currency")
  dp.callback_query.register(admin_add, F.data == "admin_add")
  dp.callback_query.register(admin_remove, F.data == "admin_remove")
  dp.callback_query.register(admin_back, F.data == "admin_back")
  dp.message.register(process_admin_username, AdminStates.entering_admin_username)

