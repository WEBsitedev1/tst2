from aiogram import Dispatcher

from handlers.user import register_user_handlers
from handlers.admin import register_admin_handlers
from handlers.dev import register_dev_handlers
from handlers.games import register_game_handlers
from handlers.status import register_status_handlers
from handlers.wallet import register_wallet_handlers
from handlers.common import register_common_handlers

def register_all_handlers(dp: Dispatcher):
  """Register all handlers"""
  # Order matters: common handlers should be registered last
  register_user_handlers(dp)
  register_admin_handlers(dp)
  register_dev_handlers(dp)
  register_game_handlers(dp)
  register_status_handlers(dp)
  register_wallet_handlers(dp)
  register_common_handlers(dp)

