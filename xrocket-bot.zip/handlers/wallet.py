from aiogram import Dispatcher, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

class WalletStates(StatesGroup):
    choosing_wallet_type = State()
    connecting = State()
    confirming = State()

async def cmd_wallet(message: Message, state: FSMContext):
    """Handle /wallet command"""
    kb = InlineKeyboardBuilder()
    kb.button(text="Connect Wallet", callback_data="wallet_connect")
    kb.button(text="Disconnect Wallet", callback_data="wallet_disconnect")
    kb.button(text="Wallet Status", callback_data="wallet_status")
    kb.adjust(1)
    
    await message.answer(
        "💼 <b>Wallet Management</b>\n\n"
        "Connect your TON wallet to participate in games and receive prizes.\n\n"
        "Choose an option below:",
        reply_markup=kb.as_markup()
    )

async def wallet_connect(callback: CallbackQuery, state: FSMContext):
    """Handle wallet_connect callback"""
    kb = InlineKeyboardBuilder()
    kb.button(text="Tonkeeper", callback_data="wallet_type_tonkeeper")
    kb.button(text="TON Wallet", callback_data="wallet_type_ton_wallet")
    kb.button(text="Back", callback_data="wallet_back")
    kb.adjust(1)
    
    await callback.message.edit_text(
        "🔗 <b>Connect Wallet</b>\n\n"
        "Choose your wallet type:",
        reply_markup=kb.as_markup()
    )
    await state.set_state(WalletStates.choosing_wallet_type)
    await callback.answer()

async def wallet_type_selected(callback: CallbackQuery, state: FSMContext):
    """Handle wallet type selection"""
    wallet_type = callback.data.split("_")[-1]
    await state.update_data(wallet_type=wallet_type)
    
    # This would typically generate a connection URL using pytonconnect
    connection_url = "https://app.tonkeeper.com/ton-connect?v=2&r=..."
    
    kb = InlineKeyboardBuilder()
    kb.button(text="Open Wallet App", url=connection_url)
    kb.button(text="Show QR Code", callback_data="wallet_show_qr")
    kb.button(text="Check Connection", callback_data="wallet_check_connection")
    kb.button(text="Cancel", callback_data="wallet_cancel")
    kb.adjust(1)
    
    await callback.message.edit_text(
        f"📱 <b>Connect {wallet_type.replace('_', ' ').title()}</b>\n\n"
        "1. Click the button below to open your wallet app\n"
        "2. Confirm the connection in your wallet\n"
        "3. Click 'Check Connection' to verify",
        reply_markup=kb.as_markup()
    )
    await state.set_state(WalletStates.connecting)
    await callback.answer()

async def wallet_show_qr(callback: CallbackQuery, state: FSMContext):
    """Show QR code for wallet connection"""
    # This would typically generate a QR code using pytonconnect
    kb = InlineKeyboardBuilder()
    kb.button(text="Check Connection", callback_data="wallet_check_connection")
    kb.button(text="Back", callback_data="wallet_back_to_connect")
    kb.adjust(1)
    
    await callback.message.edit_text(
        "📲 <b>Scan QR Code</b>\n\n"
        "Scan this QR code with your wallet app to connect.\n\n"
        "[QR Code would be displayed here]",
        reply_markup=kb.as_markup()
    )
    await callback.answer()

async def wallet_check_connection(callback: CallbackQuery, state: FSMContext):
    """Check wallet connection status"""
    # This would typically check connection status using pytonconnect
    # For demo purposes, we'll simulate a successful connection
    connected = True
    
    if connected:
        kb = InlineKeyboardBuilder()
        kb.button(text="Done", callback_data="wallet_done")
        
        await callback.message.edit_text(
            "✅ <b>Wallet Connected!</b>\n\n"
            "Your wallet has been successfully connected.\n\n"
            "Wallet Address: EQB1capxb3R-VLA3HLDVB1Rx6CHpWQA_7MOg1hqL2Cw2x_dz\n"
            "Wallet Type: Tonkeeper",
            reply_markup=kb.as_markup()
        )
        await state.clear()
    else:
        kb = InlineKeyboardBuilder()
        kb.button(text="Try Again", callback_data="wallet_connect")
        kb.button(text="Cancel", callback_data="wallet_cancel")
        kb.adjust(1)
        
        await callback.message.edit_text(
            "❌ <b>Connection Failed</b>\n\n"
            "Could not detect a connected wallet. Please try again.",
            reply_markup=kb.as_markup()
        )
    
    await callback.answer()

async def wallet_disconnect(callback: CallbackQuery):
    """Handle wallet_disconnect callback"""
    # This would typically disconnect the wallet using pytonconnect
    kb = InlineKeyboardBuilder()
    kb.button(text="Confirm Disconnect", callback_data="wallet_confirm_disconnect")
    kb.button(text="Cancel", callback_data="wallet_cancel")
    kb.adjust(1)
    
    await callback.message.edit_text(
        "⚠️ <b>Disconnect Wallet</b>\n\n"
        "Are you sure you want to disconnect your wallet?\n\n"
        "Wallet Address: EQB1capxb3R-VLA3HLDVB1Rx6CHpWQA_7MOg1hqL2Cw2x_dz",
        reply_markup=kb.as_markup()
    )
    await callback.answer()

async def wallet_confirm_disconnect(callback: CallbackQuery):
    """Confirm wallet disconnection"""
    # This would typically disconnect the wallet using pytonconnect
    kb = InlineKeyboardBuilder()
    kb.button(text="Back to Wallet Menu", callback_data="wallet_back")
    
    await callback.message.edit_text(
        "✅ <b>Wallet Disconnected</b>\n\n"
        "Your wallet has been successfully disconnected.",
        reply_markup=kb.as_markup()
    )
    await callback.answer()

async def wallet_status(callback: CallbackQuery):
    """Show wallet status"""
    # This would typically fetch wallet info from the database
    kb = InlineKeyboardBuilder()
    kb.button(text="Back", callback_data="wallet_back")
    
    await callback.message.edit_text(
        "💼 <b>Wallet Status</b>\n\n"
        "Wallet Address: EQB1capxb3R-VLA3HLDVB1Rx6CHpWQA_7MOg1hqL2Cw2x_dz\n"
        "Wallet Type: Tonkeeper\n"
        "Connected: Yes\n"
        "Connected Since: 2023-06-15 14:30:45",
        reply_markup=kb.as_markup()
    )
    await callback.answer()

async def wallet_back(callback: CallbackQuery, state: FSMContext):
    """Handle back button"""
    await state.clear()
    await cmd_wallet(callback.message, state)
    await callback.answer()

async def wallet_cancel(callback: CallbackQuery, state: FSMContext):
    """Handle cancel button"""
    await state.clear()
    await cmd_wallet(callback.message, state)
    await callback.answer("Operation cancelled")

def register_wallet_handlers(dp: Dispatcher):
    """Register wallet handlers"""
    dp.message.register(cmd_wallet, Command("wallet"))
    dp.callback_query.register(wallet_connect, F.data == "wallet_connect")
    dp.callback_query.register(wallet_type_selected, F.data.startswith("wallet_type_"))
    dp.callback_query.register(wallet_show_qr, F.data == "wallet_show_qr")
    dp.callback_query.register(wallet_check_connection, F.data == "wallet_check_connection")
    dp.callback_query.register(wallet_disconnect, F.data == "wallet_disconnect")
    dp.callback_query.register(wallet_confirm_disconnect, F.data == "wallet_confirm_disconnect")
    dp.callback_query.register(wallet_status, F.data == "wallet_status")
    dp.callback_query.register(wallet_back, F.data == "wallet_back")
    dp.callback_query.register(wallet_cancel, F.data == "wallet_cancel")

