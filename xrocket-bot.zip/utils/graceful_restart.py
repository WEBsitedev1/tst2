import asyncio
import logging
import json
import os
import signal
import sys
import time
from typing import Dict, Any, Optional, Callable, Awaitable, List
from datetime import datetime

logger = logging.getLogger(__name__)

class GracefulRestartManager:
    """
    Manages graceful restart of the bot.
    Saves state before shutdown and restores it on startup.
    """
    
    def __init__(self, state_file: str = "bot_state.json"):
        self.state_file = state_file
        self.save_handlers = {}
        self.restore_handlers = {}
        self.shutdown_handlers = []
        self.is_shutting_down = False
        self.restart_stats = {
            "last_shutdown": None,
            "last_startup": datetime.utcnow().isoformat(),
            "successful_restarts": 0,
            "failed_restarts": 0
        }
    
    def register_save_handler(self, name: str, handler: Callable[[], Awaitable[Dict[str, Any]]]):
        """Register a handler that saves state for a component"""
        self.save_handlers[name] = handler
    
    def register_restore_handler(self, name: str, handler: Callable[[Dict[str, Any]], Awaitable[None]]):
        """Register a handler that restores state for a component"""
        self.restore_handlers[name] = handler
    
    def register_shutdown_handler(self, handler: Callable[[], Awaitable[None]]):
        """Register a handler to be called during shutdown"""
        self.shutdown_handlers.append(handler)
    
    async def save_state(self) -> bool:
        """
        Save the current state of all registered components
        
        Returns:
            bool: True if state was saved successfully
        """
        if self.is_shutting_down:
            logger.warning("Already shutting down, not saving state again")
            return False
        
        self.is_shutting_down = True
        logger.info("Saving bot state for graceful restart...")
        
        try:
            state = {
                "restart_stats": self.restart_stats,
                "components": {}
            }
            
            # Update shutdown timestamp
            state["restart_stats"]["last_shutdown"] = datetime.utcnow().isoformat()
            
            # Save state for each component
            for name, handler in self.save_handlers.items():
                try:
                    component_state = await handler()
                    state["components"][name] = component_state
                    logger.info(f"Saved state for {name}")
                except Exception as e:
                    logger.error(f"Error saving state for {name}: {e}")
            
            # Write state to file
            with open(self.state_file, 'w') as f:
                json.dump(state, f, indent=2)
            
            logger.info(f"Bot state saved to {self.state_file}")
            return True
        
        except Exception as e:
            logger.error(f"Error saving bot state: {e}")
            return False
    
    async def restore_state(self) -> bool:
        """
        Restore state from file if it exists
        
        Returns:
            bool: True if state was restored successfully
        """
        if not os.path.exists(self.state_file):
            logger.info("No saved state found, starting fresh")
            return False
        
        try:
            with open(self.state_file, 'r') as f:
                state = json.load(f)
            
            # Проверка корректности структуры state
            if not isinstance(state, dict):
                logger.error(f"Invalid state format: expected dict, got {type(state)}")
                self.restart_stats["failed_restarts"] += 1
                return False
            
            # Restore restart statistics
            if "restart_stats" in state and isinstance(state["restart_stats"], dict):
                # Проверяем наличие всех необходимых полей
                required_fields = ["last_shutdown", "last_startup", "successful_restarts", "failed_restarts"]
                if all(field in state["restart_stats"] for field in required_fields):
                    self.restart_stats = state["restart_stats"]
                    self.restart_stats["last_startup"] = datetime.utcnow().isoformat()
                    self.restart_stats["successful_restarts"] += 1
                else:
                    logger.warning("Incomplete restart_stats in state file, using defaults")
                    self.restart_stats["last_startup"] = datetime.utcnow().isoformat()
                    self.restart_stats["successful_restarts"] += 1
            else:
                logger.warning("No valid restart_stats in state file, using defaults")
                self.restart_stats["last_startup"] = datetime.utcnow().isoformat()
                self.restart_stats["successful_restarts"] += 1
            
            # Restore component states
            if "components" in state and isinstance(state["components"], dict):
                for name, handler in self.restore_handlers.items():
                    if name in state["components"]:
                        try:
                            component_state = state["components"][name]
                            await handler(component_state)
                            logger.info(f"Restored state for {name}")
                        except Exception as e:
                            logger.error(f"Error restoring state for {name}: {e}")
            else:
                logger.warning("No valid components data in state file")
            
            # Remove the state file after successful restore
            try:
                os.remove(self.state_file)
                logger.info("Bot state restored successfully and state file removed")
            except Exception as e:
                logger.warning(f"Could not remove state file: {e}")
            
            return True
            
        except json.JSONDecodeError as e:
            logger.error(f"Error decoding state file: {e}")
            self.restart_stats["failed_restarts"] += 1
            return False
        except Exception as e:
            logger.error(f"Error restoring bot state: {e}")
            self.restart_stats["failed_restarts"] += 1
            return False
    
    async def shutdown(self, restart: bool = False):
        """
        Perform graceful shutdown
        
        Args:
            restart: Whether to restart the bot after shutdown
        """
        if self.is_shutting_down:
            return
        
        self.is_shutting_down = True
        logger.info(f"Performing graceful {'restart' if restart else 'shutdown'}...")
        
        # Save state first
        await self.save_state()
        
        # Run shutdown handlers
        for handler in self.shutdown_handlers:
            try:
                await handler()
            except Exception as e:
                logger.error(f"Error in shutdown handler: {e}")
        
        logger.info("Graceful shutdown completed")
        
        # Restart if requested
        if restart:
            logger.info("Restarting bot...")
            os.execv(sys.executable, [sys.executable] + sys.argv)
    
    def setup_signal_handlers(self):
        """Set up signal handlers for graceful shutdown"""
        loop = asyncio.get_event_loop()
        
        # Handle SIGINT (Ctrl+C) and SIGTERM
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(
                sig,
                lambda: asyncio.create_task(self.shutdown())
            )
        
        # Handle SIGHUP for restart
        if hasattr(signal, 'SIGHUP'):  # SIGHUP is not available on Windows
            loop.add_signal_handler(
                signal.SIGHUP,
                lambda: asyncio.create_task(self.shutdown(restart=True))
            )
        
        logger.info("Signal handlers for graceful shutdown set up")
    
    def get_stats(self):
        """Get restart statistics"""
        return self.restart_stats

