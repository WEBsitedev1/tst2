import logging
import asyncio
import os
from datetime import datetime, timedelta
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import delete, func

from database.models import Log

logger = logging.getLogger(__name__)

class LogRotationManager:
    """
    Manages log rotation for the database logs table.
    Deletes logs older than the specified retention period.
    """
    
    def __init__(self, session_maker, retention_days: int = 14):
        self.session_maker = session_maker
        self.retention_days = retention_days
        self.running = False
        self.task = None
        self.stats = {
            "last_run": None,
            "deleted_count": 0,
            "total_runs": 0,
            "errors": 0
        }
    
    async def start(self, interval_hours: int = 24):
        """
        Start the log rotation task
        
        Args:
            interval_hours: How often to run the rotation (in hours)
        """
        if self.running:
            logger.warning("Log rotation is already running")
            return
        
        self.running = True
        self.task = asyncio.create_task(self._rotation_task(interval_hours))
        logger.info(f"Log rotation started with {self.retention_days} days retention")
    
    async def stop(self):
        """Stop the log rotation task"""
        if not self.running:
            return
        
        self.running = False
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
        logger.info("Log rotation stopped")
    
    async def _rotation_task(self, interval_hours: int):
        """Background task that runs the log rotation periodically"""
        while self.running:
            try:
                await self._rotate_logs()
                self.stats["last_run"] = datetime.utcnow().isoformat()
                self.stats["total_runs"] += 1
                
                # Sleep until next rotation
                await asyncio.sleep(interval_hours * 3600)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in log rotation task: {e}")
                self.stats["errors"] += 1
                # Sleep for a shorter time if there was an error
                await asyncio.sleep(3600)
    
    async def _rotate_logs(self):
        """Perform the actual log rotation"""
        cutoff_date = datetime.utcnow() - timedelta(days=self.retention_days)
        
        async with self.session_maker() as session:
            try:
                # Check if we're using JSON storage
                if hasattr(session, '_read_json_file'):
                    # JSON storage implementation
                    logs_file = os.path.join(session.data_path, "global", "logs.json")
                    if os.path.exists(logs_file):
                        logs_data = await session._read_json_file(logs_file)
                        
                        # Проверка корректности формата данных
                        if not isinstance(logs_data, dict):
                            logger.error(f"Invalid logs data format: expected dict, got {type(logs_data)}")
                            return
                        
                        # Filter logs by date
                        logs_to_keep = {}
                        logs_to_delete = []
                        deleted_count = 0
                        
                        for log_id, log in logs_data.items():
                            # Проверка корректности формата записи
                            if not isinstance(log, dict) or "timestamp" not in log:
                                logger.warning(f"Invalid log record format for ID {log_id}, skipping")
                                logs_to_keep[log_id] = log
                                continue
                                
                            try:
                                log_date = datetime.fromisoformat(log.get("timestamp", ""))
                                if log_date >= cutoff_date:
                                    logs_to_keep[log_id] = log
                                else:
                                    logs_to_delete.append(log_id)
                                    deleted_count += 1
                            except (ValueError, TypeError) as e:
                                logger.warning(f"Invalid timestamp format in log ID {log_id}: {e}")
                                logs_to_keep[log_id] = log
                        
                        if logs_to_delete:
                            # Write back only the logs to keep
                            await session._write_json_file(logs_file, logs_to_keep)
                            self.stats["deleted_count"] += deleted_count
                            logger.info(f"Deleted {deleted_count} logs older than {self.retention_days} days")
                        else:
                            logger.info(f"No logs older than {self.retention_days} days to delete")
                else:
                    # Database implementation
                    try:
                        # Count logs to be deleted
                        count_query = select(func.count()).select_from(Log).where(Log.timestamp < cutoff_date)
                        result = await session.execute(count_query)
                        count = result.scalar()
                        
                        if count is None:
                            logger.warning("Could not get count of logs to delete")
                            count = 0
                        
                        if count > 0:
                            # Delete logs older than retention period
                            delete_query = delete(Log).where(Log.timestamp < cutoff_date)
                            await session.execute(delete_query)
                            await session.commit()
                            self.stats["deleted_count"] += count
                            logger.info(f"Deleted {count} logs older than {self.retention_days} days")
                        else:
                            logger.info(f"No logs older than {self.retention_days} days to delete")
                    except Exception as e:
                        await session.rollback()
                        logger.error(f"Database error during log rotation: {e}")
                        raise
            
            except Exception as e:
                if not hasattr(session, '_read_json_file'):
                    await session.rollback()
                self.stats["errors"] += 1
                logger.error(f"Error rotating logs: {e}")
                raise
    
    def get_stats(self):
        """Get statistics about log rotation"""
        return self.stats

