import asyncio
import logging
import json
from typing import Dict, Any, Callable, Awaitable, Optional, List
from collections import defaultdict

logger = logging.getLogger(__name__)

class QueueManager:
    """
    Manages asyncio queues for different types of operations.
    Implements rate limiting and overflow protection.
    """
    
    def __init__(self, max_queue_size: int = 100):
        self.max_queue_size = max_queue_size
        self.queues = {
            "game_actions": asyncio.Queue(maxsize=max_queue_size),
            "admin_commands": asyncio.Queue(maxsize=max_queue_size),
            "financial_operations": asyncio.Queue(maxsize=max_queue_size)
        }
        self.workers = {}
        self.running = True
        self.stats = defaultdict(int)  # Track processed tasks for each queue
    
    async def start_workers(self):
        """Start worker tasks for all queues"""
        for queue_name in self.queues:
            self.workers[queue_name] = asyncio.create_task(
                self._worker(queue_name, self.queues[queue_name])
            )
        logger.info("Queue workers started")
    
    async def stop_workers(self):
        """Stop all worker tasks"""
        if not self.workers:
            logger.info("No workers to stop")
            return
        
        self.running = False
        
        # Создаем копию словаря, чтобы избежать изменения во время итерации
        workers_copy = dict(self.workers)
        
        # Отменяем все задачи
        for name, worker in workers_copy.items():
            if not worker.done() and not worker.cancelled():
                worker.cancel()
                logger.debug(f"Worker {name} cancelled")
        
        # Ждем завершения всех задач с обработкой исключений
        for name, worker in workers_copy.items():
            try:
                await asyncio.wait_for(worker, timeout=5.0)
                logger.debug(f"Worker {name} stopped gracefully")
            except asyncio.CancelledError:
                logger.debug(f"Worker {name} was cancelled")
            except asyncio.TimeoutError:
                logger.warning(f"Timeout waiting for worker {name} to stop")
            except Exception as e:
                logger.error(f"Error stopping worker {name}: {e}")
        
        # Очищаем словарь workers
        self.workers.clear()
        logger.info("All queue workers stopped")
    
    async def _worker(self, queue_name: str, queue: asyncio.Queue):
        """Worker task that processes items from the queue"""
        logger.info(f"Starting worker for queue: {queue_name}")
        while self.running:
            try:
                # Используем wait_for с таймаутом, чтобы периодически проверять self.running
                try:
                    task_data = await asyncio.wait_for(queue.get(), timeout=1.0)
                except asyncio.TimeoutError:
                    # Проверяем, все еще работаем ли мы
                    continue
                
                func = task_data.get("func")
                args = task_data.get("args", [])
                kwargs = task_data.get("kwargs", {})
                
                if not callable(func):
                    logger.error(f"Non-callable function in {queue_name} queue")
                    queue.task_done()
                    continue
                
                try:
                    await func(*args, **kwargs)
                    self.stats[queue_name] += 1
                except asyncio.CancelledError:
                    # Пробрасываем CancelledError для корректной остановки
                    raise
                except Exception as e:
                    logger.error(f"Error processing task in {queue_name} queue: {e}")
                finally:
                    # Всегда отмечаем задачу как выполненную
                    queue.task_done()
                
            except asyncio.CancelledError:
                # Корректно обрабатываем отмену задачи
                logger.info(f"Worker for queue {queue_name} cancelled")
                break
            except Exception as e:
                logger.error(f"Unexpected error in {queue_name} queue worker: {e}")
                # Небольшая пауза перед повторной попыткой
                await asyncio.sleep(0.1)
    
        logger.info(f"Worker for queue {queue_name} stopped")
    
    async def add_task(self, queue_name: str, func: Callable[..., Awaitable[Any]], *args, **kwargs) -> bool:
        """
        Add a task to the specified queue
        
        Returns:
            bool: True if task was added, False if queue is full
        """
        if queue_name not in self.queues:
            logger.error(f"Queue {queue_name} does not exist")
            return False
        
        queue = self.queues[queue_name]
        
        if queue.full():
            logger.warning(f"Queue {queue_name} is full, task rejected")
            return False
        
        task_data = {
            "func": func,
            "args": args,
            "kwargs": kwargs
        }
        
        await queue.put(task_data)
        logger.debug(f"Task added to {queue_name} queue, size: {queue.qsize()}/{self.max_queue_size}")
        return True
    
    def get_queue_sizes(self) -> Dict[str, int]:
        """Get current sizes of all queues"""
        return {name: queue.qsize() for name, queue in self.queues.items()}
    
    def get_stats(self) -> Dict[str, int]:
        """Get statistics on processed tasks"""
        return dict(self.stats)
    
    async def save_state(self) -> Dict[str, Any]:
        """
        Save the current state of all queues for graceful restart
        
        Returns:
            Dict[str, Any]: State data that can be used to restore queues
        """
        state = {
            "stats": dict(self.stats),
            "queues": {}
        }
        
        for queue_name, queue in self.queues.items():
            # We can't directly serialize the queue items because they contain functions
            # Instead, we'll save metadata about the tasks that can be used for monitoring
            queue_size = queue.qsize()
            state["queues"][queue_name] = {
                "size": queue_size,
                "pending_tasks": queue_size
            }
        
        return state
    
    async def restore_state(self, state: Dict[str, Any]):
        """Restore queue statistics from saved state"""
        if not state:
            logger.warning("No state to restore")
            return
            
        if "stats" in state:
            self.stats = defaultdict(int, state["stats"])
            logger.info(f"Restored queue statistics: {dict(self.stats)}")
        
        # We can't restore actual queue items since they contain functions
        # But we can log information about the lost tasks
        if "queues" in state:
            for queue_name, queue_data in state["queues"].items():
                if queue_name in self.queues and queue_data.get("pending_tasks", 0) > 0:
                    logger.warning(f"Lost {queue_data['pending_tasks']} pending tasks from {queue_name} queue during restart")

