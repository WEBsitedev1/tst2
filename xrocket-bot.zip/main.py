import asyncio
import logging
import sys
import os
from pathlib import Path
from datetime import datetime
from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.fsm.storage.redis import RedisStorage
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.client.default import DefaultBotProperties

from config.config import load_config
from database.base import create_async_engine, get_session_maker
from middlewares.group_middleware import GroupMiddleware
from middlewares.admin_middleware import AdminMiddleware
from handlers import register_all_handlers
from utils.logger import setup_logger
from utils.redis_cache import RedisCache
from utils.queue_manager import QueueManager
from utils.log_rotation import LogRotationManager
from utils.graceful_restart import GracefulRestartManager
from storage.json_storage import JsonSessionMaker, JsonRedisCache

async def main():
    # Setup logging
    setup_logger()
    logger = logging.getLogger(__name__)
    logger.info("Starting bot...")

    # Load configuration
    config = load_config()

    # Initialize storage based on configuration
    if config.storage.use_json:
        logger.info("Using JSON storage")
        session_maker = JsonSessionMaker(config.storage.json_data_path)
        redis_cache = JsonRedisCache(config.storage.json_data_path)
        storage = MemoryStorage()  # Use memory storage for FSM when in JSON mode
    else:
        logger.info("Using database and Redis storage")
        # Initialize Redis
        redis_cache = RedisCache(
            host=config.redis.host,
            port=config.redis.port,
            password=config.redis.password,
            db=config.redis.db
        )
        
        # Initialize Redis storage for FSM
        storage = RedisStorage.from_url(
            f"redis://{config.redis.host}:{config.redis.port}/{config.redis.db}",
            password=config.redis.password
        )
        
        # Initialize database
        engine = create_async_engine(config.db)
        session_maker = get_session_maker(engine)

    # Initialize queue manager
    queue_manager = QueueManager()
    await queue_manager.start_workers()

    # Initialize log rotation
    log_rotation = LogRotationManager(session_maker)
    await log_rotation.start()

    # Initialize graceful restart manager
    restart_manager = GracefulRestartManager()

    # Register state handlers for graceful restart
    restart_manager.register_save_handler("queue_manager", queue_manager.save_state)
    restart_manager.register_restore_handler("queue_manager", queue_manager.restore_state)
    restart_manager.register_shutdown_handler(queue_manager.stop_workers)
    restart_manager.register_shutdown_handler(log_rotation.stop)

    # Setup signal handlers
    restart_manager.setup_signal_handlers()

    # Try to restore state if available
    await restart_manager.restore_state()

    # Initialize bot and dispatcher
    bot = Bot(
        token=config.tg_bot.token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML)
    )
    dp = Dispatcher(storage=storage)

    # Проверка, что session_maker действительно создает сессию
    try:
        if config.storage.use_json:
            # Для JSON хранилища проверяем, что директория существует и доступна для записи
            json_path = Path(config.storage.json_data_path)
            if not json_path.exists():
                json_path.mkdir(parents=True, exist_ok=True)
                logger.info(f"Created JSON storage directory: {json_path}")
            
            # Проверяем права доступа
            test_file = json_path / "test_access.tmp"
            try:
                with open(test_file, 'w') as f:
                    f.write("test")
                os.remove(test_file)
            except Exception as e:
                logger.error(f"JSON storage directory is not writable: {e}")
                raise RuntimeError("JSON storage directory is not writable")
        else:
            # Для базы данных проверяем соединение
            try:
                async with session_maker() as session:
                    # Простой запрос для проверки соединения
                    await session.execute("SELECT 1")
                logger.info("Database connection verified successfully")
            except Exception as e:
                logger.critical(f"Failed to connect to database: {e}")
                raise RuntimeError(f"Failed to connect to database: {e}")
        
        logger.info("Storage connection verified successfully")
    except Exception as e:
        logger.critical(f"Failed to verify storage connection: {e}")
        # Останавливаем все запущенные сервисы перед выходом
        await queue_manager.stop_workers()
        await log_rotation.stop()
        sys.exit(1)

    # Add session to bot for handlers to access
    bot["db_session"] = session_maker
    bot["redis_cache"] = redis_cache
    bot["queue_manager"] = queue_manager
    bot["restart_manager"] = restart_manager
    bot["start_time"] = datetime.utcnow()

    # Register middlewares
    dp.update.middleware(GroupMiddleware(session_maker, redis_cache))
    dp.update.middleware(AdminMiddleware(session_maker, redis_cache))

    # Register all handlers
    register_all_handlers(dp)

    # Start polling
    try:
        logger.info("Bot started")
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    except Exception as e:
        logger.error(f"Error during bot execution: {e}")
        await restart_manager.shutdown()
    finally:
        await bot.session.close()
        await redis_cache.close()
        await queue_manager.stop_workers()
        await log_rotation.stop()
        logger.info("Bot stopped")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logging.info("Bot stopped")

